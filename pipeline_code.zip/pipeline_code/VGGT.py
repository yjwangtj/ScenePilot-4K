
import os, glob, json
from collections import defaultdict
from typing import List, Dict, Tuple, Optional
import numpy as np
import cv2
import torch
from scipy.spatial.distance import cdist
from datetime import datetime
import gc
from segment_anything import sam_model_registry, SamPredictor

#路径配置
VGGT_WEIGHTS_DIR = "your VGGT weight path"
IMAGE_ROOT       = "your images path"
ANNOTATION_ROOT  = "your YOLO output path"
OUTPUT_ROOT      = "your output path"

# 超参数：选择要处理的场景 
SCENE_LIST = [
    "xxx",#文件夹名称
]


BATCH_SIZE = 10
SKIP_EXISTING = True


SAM_MODEL_TYPE = "your SAM type"
SAM_CHECKPOINT_PATH = "your SAM.pth"


BBOX_OVERLAP_THRESHOLD = 0.4
BBOX_SIZE_THRESHOLD = 0.4


EDGE_PAD_PX            = 2
BOTTOM_IGNORE_DEFAULT  = 0.08
CLOSEST_PERCENTILE     = 5.0
USE_HARD_MIN           = False
MIN_MASK_AREA_PX       = 40


CAM_HEIGHT_M = 1.63


GROUND_Y_MIN_FRAC      = 0.50
GROUND_X_MARGIN_FRAC   = 0.10
GROUND_STRIDE          = 3
GROUND_MIN_SAMPLES     = 1000
MAD_SCALE              = 1.4826
INLIER_THR_SIGMA       = 3.0
FRAMESCALE_MIN_INLIER  = 300
FRAMESCALE_MAX_RESID   = 0.05


CLASS_HEIGHT_PRIOR = {
    "person": 1.70, "pedestrian": 1.70,
    "cyclist": 1.70, "bicycle": 1.50, "motorcycle": 1.40, "rider": 1.70,
    "car": 1.50, "vehicle": 1.50, "auto": 1.50,
    "truck": 3.00, "bus": 3.00, "van": 2.30,
}
DEFAULT_HEIGHT_PRIOR = 1.60

VERBOSE = True
LOG_FIRST_N = 5

# VGGT 导入
from vggt.models.vggt import VGGT
from vggt.utils.load_fn import load_and_preprocess_images
from vggt.utils.pose_enc import pose_encoding_to_extri_intri
from vggt.utils.geometry import unproject_depth_map_to_point_map
from PIL import UnidentifiedImageError

# 工具函数 
def list_images(root: str) -> List[str]:
    exts = ("*.jpg", "*.jpeg", "*.png", "*.JPG", "*.JPEG", "*.PNG")
    files = []
    for e in exts:
        files.extend(glob.glob(os.path.join(root, e)))
    return sorted([f for f in files if os.path.isfile(f)])

def subdirs(root: str) -> List[str]:
    return sorted([os.path.join(root, d) for d in os.listdir(root)
                   if os.path.isdir(os.path.join(root, d))])

def load_annotations_map(json_path: str) -> Dict[str, List[Dict]]:
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    img2items = defaultdict(list)
    for e in data:  
        name = e.get("image_name")
        if not name: continue
        base = os.path.basename(name)
        for obj in e.get("key_objects", []):
            b = obj.get("bbox_2d")
            if b and len(b) == 4:
                lab = str(obj.get("label", "vehicle")).lower()
                img2items[base].append({
                    "bbox": tuple(map(float, b)),
                    "label": lab,
                    "object_id": str(obj.get("object_id", "0"))
                })
    return img2items


def compute_iou_and_overlap(box1, box2):
    x0 = max(box1[0], box2[0])
    y0 = max(box1[1], box2[1])
    x1 = min(box1[2], box2[2])
    y1 = min(box1[3], box2[3])
    if x1 <= x0 or y1 <= y0:
        return 0.0
    inter_area = (x1 - x0) * (y1 - y0)
    area1 = (box1[2] - box1[0]) * (box1[3] - box1[1])
    area2 = (box2[2] - box2[0]) * (box2[3] - box2[1])
    max_area = max(area1, area2)
    overlap_ratio = inter_area / max_area
    return overlap_ratio

def filter_bboxes_by_overlap_and_size(bboxes_xyxy, img_area, overlap_thr=0.4, size_thr=0.4):
    if len(bboxes_xyxy) == 0:
        return []
    areas = [(b[2] - b[0]) * (b[3] - b[1]) for b in bboxes_xyxy]
    valid_indices = [i for i, area in enumerate(areas) if area <= size_thr * img_area]
    if len(valid_indices) <= 1:
        return valid_indices
    to_remove = set()
    n = len(valid_indices)
    for i in range(n):
        if valid_indices[i] in to_remove:
            continue
        for j in range(i + 1, n):
            if valid_indices[j] in to_remove:
                continue
            box_i = bboxes_xyxy[valid_indices[i]]
            box_j = bboxes_xyxy[valid_indices[j]]
            overlap_ratio = compute_iou_and_overlap(box_i, box_j)
            if overlap_ratio > overlap_thr:
                if areas[valid_indices[i]] >= areas[valid_indices[j]]:
                    to_remove.add(valid_indices[j])
                else:
                    to_remove.add(valid_indices[i])
                    break
    final_indices = [idx for idx in valid_indices if idx not in to_remove]
    return final_indices

def bbox_xyxy_from_norm(bbox, W, H):
    cx, cy, bw, bh = bbox
    x0 = int(round((cx - bw / 2) * W))
    y0 = int(round((cy - bh / 2) * H))
    x1 = int(round((cx + bw / 2) * W))
    y1 = int(round((cy + bh / 2) * H))
    x0 = max(0, x0)
    y0 = max(0, y0)
    x1 = min(W - 1, x1)
    y1 = min(H - 1, y1)
    return x0, y0, x1, y1

def rect_mask(H, W, rect_xyxy):
    x0, y0, x1, y1 = rect_xyxy
    m = np.zeros((H, W), np.uint8)
    m[y0:y1 + 1, x0:x1 + 1] = 1
    return m

def camera_dist_and_z_from_mask(mask01: np.ndarray, pointmap_hw3: np.ndarray, E: np.ndarray):
    ys, xs = np.where(mask01 > 0)
    if ys.size == 0:
        return np.array([], dtype=np.float32), np.array([], dtype=np.float32)
    Pw = pointmap_hw3[ys, xs, :]
    finite = np.isfinite(Pw).all(axis=1)
    Pw = Pw[finite]
    if Pw.shape[0] == 0:
        return np.array([], dtype=np.float32), np.array([], dtype=np.float32)
    R = E[:, :3]
    t = E[:, 3:4]
    Pc = (R @ Pw.T + t).T
    d = np.linalg.norm(Pc, axis=1).astype(np.float32)
    z = Pc[:, 2].astype(np.float32)
    return d, z

def compute_azimuth_angle_in_camera_frame(Pc: np.ndarray) -> float:
    if len(Pc) == 0:
        return 0.0
    center = np.mean(Pc, axis=0)
    dx = center[0]
    dz = center[2]
    if abs(dz) < 1e-6 and abs(dx) < 1e-6:
        return 0.0
    angle_rad = np.arctan2(dx, dz)
    angle_deg = np.degrees(angle_rad)
    if angle_deg < -90:
        angle_deg += 180
    elif angle_deg > 90:
        angle_deg -= 180
    return float(angle_deg)

def compute_robust_min_distance(ptsA: np.ndarray, ptsB: np.ndarray) -> Optional[float]:
    if len(ptsA) == 0 or len(ptsB) == 0:
        return None
    dist_matrix = cdist(ptsA, ptsB)
    dist_flat = dist_matrix.flatten()
    if len(dist_flat) == 0:
        return None
    thr = np.percentile(dist_flat, 5.0)
    valid_dists = dist_flat[dist_flat >= thr]
    if len(valid_dists) == 0:
        return None
    return float(np.min(valid_dists))

# SAM 
class SamSegmenter:
    def __init__(self, model_type=SAM_MODEL_TYPE, checkpoint_path=SAM_CHECKPOINT_PATH):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"→ Loading SAM ({model_type}) from {checkpoint_path} on {self.device}...")
        sam = sam_model_registry[model_type](checkpoint=checkpoint_path)
        sam.to(device=self.device)
        self.predictor = SamPredictor(sam)
        print("→SAM loaded.")

    def predict_batch(self, image_bgr_list: List[np.ndarray], bboxes_xyxy_list: List[List[Tuple[int, int, int, int]]]):
        all_masks = []
        for img, bboxes in zip(image_bgr_list, bboxes_xyxy_list):
            if len(bboxes) == 0:
                all_masks.append([])
                continue
            img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
            self.predictor.set_image(img_rgb)
            input_boxes = np.array(bboxes, dtype=np.float32)
            masks, scores, _ = self.predictor.predict(
                point_coords=None,
                point_labels=None,
                box=input_boxes,
                multimask_output=False,
            )
            masks_uint8 = [m.astype(np.uint8) for m in masks]
            all_masks.append(masks_uint8)
            self.predictor.reset_image()
        return all_masks

# VGGT 
class VggtEngine:
    def __init__(self, weights_dir: str):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        print(f"→ Loading VGGT model on {self.device}...")
        self.model = VGGT.from_pretrained(weights_dir).to(self.device)
        print("→  VGGT model loaded.")
        major = torch.cuda.get_device_capability()[0] if torch.cuda.is_available() else 0
        self.dtype = torch.bfloat16 if major >= 8 else torch.float16

    def infer_batch(self, image_paths: List[str]) -> Dict[str, Dict]:
        imgs = load_and_preprocess_images(image_paths).to(self.device)
        imgs_b = imgs.unsqueeze(0)
        with torch.no_grad():
            cm = torch.cuda.amp.autocast(enabled=(self.device == "cuda"), dtype=self.dtype)
            with cm:
                agg_tokens, ps_idx = self.model.aggregator(imgs_b)
                pose_enc = self.model.camera_head(agg_tokens)[-1]
                E, K = pose_encoding_to_extri_intri(pose_enc, imgs.shape[-2:])
                depth_map, _ = self.model.depth_head(agg_tokens, imgs_b, ps_idx)
                E = E.squeeze(0)
                K = K.squeeze(0)
                depth_s = depth_map.squeeze(0)
                point_map_world = unproject_depth_map_to_point_map(depth_s, E, K)

        def to_hwc3(x):
            if isinstance(x, torch.Tensor):
                x = x.detach().cpu().numpy()
            if x.ndim == 3 and x.shape[0] == 3:
                x = x.transpose(1, 2, 0)
            return x.astype(np.float32, copy=False)

        out = {}
        for i, p in enumerate(image_paths):
            Ki = K[i].detach().cpu().numpy().astype(np.float32)
            Ei = E[i].detach().cpu().numpy().astype(np.float32)
            PM = to_hwc3(point_map_world[i])
            vis = imgs[i].detach().cpu().numpy().transpose(1, 2, 0)
            vis = (np.clip((vis - vis.min()) / (vis.max() - vis.min() + 1e-6), 0, 1) * 255).astype(np.uint8)
            out[p] = dict(K=Ki, E=Ei, pointmap=PM, vis=vis)
        return out

# 几何辅助 
def estimate_world_up(E: np.ndarray) -> np.ndarray:
    R = E[:, :3]
    cam_up = np.array([0.0, -1.0, 0.0], np.float32)
    up = R.T @ cam_up
    n = np.linalg.norm(up) + 1e-9
    return (up / n).astype(np.float32)

def camera_center_world(E: np.ndarray) -> np.ndarray:
    R = E[:, :3]
    t = E[:, 3]
    return (-R.T @ t).astype(np.float32)

def estimate_frame_scale_with_ground(pointmap_hw3: np.ndarray, E: np.ndarray,
                                     img_h: int, img_w: int,
                                     h_cam_m: float = CAM_HEIGHT_M):
    H, W = img_h, img_w
    up = estimate_world_up(E)
    Cw = camera_center_world(E)
    y0 = int(H * GROUND_Y_MIN_FRAC)
    x0 = int(W * GROUND_X_MARGIN_FRAC)
    x1 = int(W * (1.0 - GROUND_X_MARGIN_FRAC)) - 1
    xs = np.arange(x0, x1 + 1, GROUND_STRIDE, dtype=np.int32)
    ys = np.arange(y0, H, GROUND_STRIDE, dtype=np.int32)
    if xs.size == 0 or ys.size == 0:
        return None, {"reason": "no_candidate_region"}
    grid_x, grid_y = np.meshgrid(xs, ys)
    Pw = pointmap_hw3[grid_y, grid_x, :]
    Pw = Pw.reshape(-1, 3).astype(np.float32)
    mask = np.isfinite(Pw).all(axis=1)
    Pw = Pw[mask]
    if Pw.shape[0] < GROUND_MIN_SAMPLES:
        return None, {"reason": "few_points", "N": int(Pw.shape[0])}
    hvals = Pw @ up
    d = -np.median(hvals)
    resid = hvals + d
    mad = np.median(np.abs(resid - np.median(resid))) + 1e-9
    sigma = MAD_SCALE * mad
    thr = INLIER_THR_SIGMA * sigma
    inliers = np.abs(resid) < thr
    Nin = int(np.count_nonzero(inliers))
    if Nin < FRAMESCALE_MIN_INLIER:
        h_pred_fallback = float(abs(up @ Cw + d))
        if h_pred_fallback > 1e-6:
            s_frame = float(h_cam_m / h_pred_fallback)
            debug_dict = {
                "Nin": int(Nin),
                "thr": float(thr),
                "h_pred": float(h_pred_fallback),
                "s": float(s_frame),
                "reason": "fallback_median_height",
                "fallback": True
            }
            return s_frame, debug_dict
        else:
            return None, {"reason": "h_pred_zero_fallback", "Nin": Nin}
    h_pred = float(abs(up @ Cw + d))
    if thr > FRAMESCALE_MAX_RESID:
        return None, {"reason": "resid_too_large", "thr": float(thr)}
    if h_pred <= 1e-6:
        return None, {"reason": "h_pred_zero"}
    s_frame = float(h_cam_m / h_pred)
    debug_dict = {
        "Nin": int(Nin),
        "thr": float(thr),
        "h_pred": float(h_pred),
        "s": float(s_frame),
        "reason": None,
        "fallback": False
    }
    return s_frame, debug_dict



class BatchProcessor:
    def __init__(self, weights_dir: str):
        self.weights_dir = weights_dir
        self.engine = None
        self.sam_segmenter = None
        self.total_processed_frames = 0
        self.total_saved_batches = 0

    def get_engine(self):
        if self.engine is None:
            self.engine = VggtEngine(self.weights_dir)
        return self.engine

    def get_sam_segmenter(self):
        if self.sam_segmenter is None:
            self.sam_segmenter = SamSegmenter()
        return self.sam_segmenter

    def process_one_target(self, vis, PM, E, K, item, s_frame: float = None):
        H, W = vis.shape[:2]
        cx, cy, bw, bh = item["bbox"]
        x0, y0, x1, y1 = bbox_xyxy_from_norm(item["bbox"], W, H)
        lab = item.get("label", "vehicle").lower()
        bottom_ignore_ratio = 0.0 if lab in ("person", "pedestrian", "bicycle", "cyclist", "motorcycle", "rider") \
            else BOTTOM_IGNORE_DEFAULT

        vis_bgr = cv2.cvtColor(vis, cv2.COLOR_RGB2BGR)
        sam = self.get_sam_segmenter()
        masks = sam.predict_batch([vis_bgr], [[(x0, y0, x1, y1)]])
        m = masks[0][0] if len(masks[0]) > 0 else np.zeros((H, W), dtype=np.uint8)
        if np.count_nonzero(m) < MIN_MASK_AREA_PX:
            m = rect_mask(H, W, (x0, y0, x1, y1))
        ys, xs = np.where(m > 0)
        if ys.size == 0:
            return None
        Pw = PM[ys, xs, :]
        finite = np.isfinite(Pw).all(axis=1)
        Pw = Pw[finite]
        if Pw.shape[0] == 0:
            return None
        R = E[:, :3]
        t = E[:, 3:4]
        Pc = (R @ Pw.T + t).T
        dists = np.linalg.norm(Pc, axis=1)
        if dists.size == 0:
            return None
        d_pred = float(np.min(dists)) if USE_HARD_MIN else float(np.percentile(dists, CLOSEST_PERCENTILE))
        scale_info = {
            "method": "frame_scale",
            "s_used": s_frame,
            "h_pred": None,
            "fy": None,
            "H_prior": None,
            "h_px": None,
            "z_pred": None,
            "label": None
        }
        if s_frame is None:
            H_prior = CLASS_HEIGHT_PRIOR.get(lab, DEFAULT_HEIGHT_PRIOR)
            h_px = max((y1 - y0 + 1), 1)
            fy = float(K[1, 1])
            zvals = Pc[:, 2]
            z_pred = float(np.percentile(zvals, 50)) if zvals.size > 0 else None
            if z_pred is None or z_pred <= 1e-6:
                return None
            s = float((fy * H_prior / h_px) / z_pred)
            scale_info = {
                "method": "target_scale",
                "s_used": s,
                "h_pred": None,
                "fy": fy,
                "H_prior": H_prior,
                "h_px": h_px,
                "z_pred": z_pred,
                "label": lab
            }
        else:
            up = estimate_world_up(E)
            Cw = camera_center_world(E)
            hvals = Pw @ up
            d = -np.median(hvals)
            h_pred = float(abs(up @ Cw + d))
            scale_info["h_pred"] = h_pred
            scale_info["s_used"] = s_frame
            s = s_frame
        d_meter = max(0.0, d_pred * s)
        azimuth_deg = compute_azimuth_angle_in_camera_frame(Pc)
        mask_data = {
            "mask": m.copy(),
            "points_3d_camera_meter": (Pc * s).copy(),
            "distance_to_ego_m": d_meter,
            "azimuth_angle_deg": azimuth_deg,
            "label": lab,
            "object_id": item.get("object_id", "0"),
            "bbox_2d_norm": item["bbox"],
            "mask_area_px": int(np.count_nonzero(m)),
            "scale_info": scale_info
        }
        return mask_data

    def process_video_clip(self, scene_name: str, video_clip_dir: str):
        image_paths = list_images(video_clip_dir)
        if not image_paths:
            print(f"[SKIP] {video_clip_dir} 无图片")
            return

        video_clip_basename = os.path.basename(video_clip_dir)
        video_clip_prefix = video_clip_basename[:8] 

        annotation_scene_dir = os.path.join(ANNOTATION_ROOT, scene_name)
        annotation_subdirs = subdirs(annotation_scene_dir)
        
        matching_annotation_dir = None
        for ann_dir in annotation_subdirs:
            ann_basename = os.path.basename(ann_dir)
            if ann_basename.startswith(video_clip_prefix):
                matching_annotation_dir = ann_dir
                break
        
        if matching_annotation_dir is None:
            print(f"[SKIP] 未找到匹配的标注目录: {video_clip_prefix} in {annotation_scene_dir}")
            return

        json_path = os.path.join(matching_annotation_dir, "final_output.json")
        if not os.path.isfile(json_path):
            print(f"[SKIP] 缺少标注: {json_path}")
            return

        img2items = load_annotations_map(json_path)

        video_clip_name = os.path.basename(video_clip_dir)
        out_dir = os.path.join(OUTPUT_ROOT, scene_name, video_clip_name)
        os.makedirs(out_dir, exist_ok=True)

        existing_batches = self.get_existing_batches_global()
        if existing_batches:
            print(f"  → 发现 {len(existing_batches)} 个已处理的batch")

        image_paths_sorted = sorted(image_paths, key=lambda x: os.path.basename(x))
        total_frames = len(image_paths_sorted)
        num_batches = total_frames // BATCH_SIZE
        if num_batches == 0:
            print(f"[SKIP] {video_clip_name} 帧数不足 {BATCH_SIZE}")
            return

        print(f"→ Processing: {scene_name}/{video_clip_name} ({num_batches} batches)")

        for b in range(num_batches):
            current_batch_id = self.total_saved_batches
            
            if SKIP_EXISTING and current_batch_id in existing_batches:
                if b < 3 or (b+1) % 10 == 0 or b+1 == num_batches:
                    print(f"  → Skip existing batch {current_batch_id}")
                self.total_saved_batches += 1 
                continue

            start_idx = b * BATCH_SIZE
            batch_paths = image_paths_sorted[start_idx:start_idx + BATCH_SIZE]

            batch_valid = True
            for p in batch_paths:
                try:
                    from PIL import Image
                    Image.open(p).verify()
                except Exception as e:
                    print(f"  [BATCH SKIP] 因损坏图片跳过整个 batch {current_batch_id}: {os.path.basename(p)} —— {str(e)}")
                    batch_valid = False
                    break
            if not batch_valid:
                self.total_saved_batches += 1  
                continue

            if b < 3 or (b+1) % 10 == 0 or b+1 == num_batches:
                print(f"  → Batch {current_batch_id} ({len(batch_paths)} frames)")

            try:
                engine = self.get_engine()
                res = engine.infer_batch(batch_paths)
            except Exception as e:
                print(f"  [BATCH SKIP] VGGT 推理失败 batch {current_batch_id}: {str(e)}")
                self.total_saved_batches += 1 
                continue

            s_frame_values = []
            for p in batch_paths:
                if p in res:
                    PM = res[p]["pointmap"]
                    E = res[p]["E"]
                    H, W = res[p]["vis"].shape[:2]
                    s_frame, _ = estimate_frame_scale_with_ground(PM, E, H, W, CAM_HEIGHT_M)
                    if s_frame is not None:
                        s_frame_values.append(s_frame)

            if not s_frame_values:
                fallback_s_values = []
                for p in batch_paths:
                    if p in res:
                        PM = res[p]["pointmap"]
                        E = res[p]["E"]
                        H, W = res[p]["vis"].shape[:2]
                 
                        up = estimate_world_up(E)
                        Cw = camera_center_world(E)
                        y0 = int(H * GROUND_Y_MIN_FRAC)
                        x0 = int(W * GROUND_X_MARGIN_FRAC)
                        x1 = int(W * (1.0 - GROUND_X_MARGIN_FRAC)) - 1
                        xs = np.arange(x0, x1 + 1, GROUND_STRIDE, dtype=np.int32)
                        ys = np.arange(y0, H, GROUND_STRIDE, dtype=np.int32)
                        if xs.size > 0 and ys.size > 0:
                            grid_x, grid_y = np.meshgrid(xs, ys)
                            Pw = PM[grid_y, grid_x, :]
                            Pw = Pw.reshape(-1, 3)
                            mask = np.isfinite(Pw).all(axis=1)
                            Pw = Pw[mask]
                            if len(Pw) >= 100:  
                                hvals = Pw @ up
                                d = -np.median(hvals)
                                h_pred = float(abs(up @ Cw + d))
                                if h_pred > 1e-6:
                                    s_fallback = CAM_HEIGHT_M / h_pred
                                    fallback_s_values.append(s_fallback)
                
                final_s = np.mean(fallback_s_values) if fallback_s_values else 1.0
            else:
                final_s = np.mean(s_frame_values)

            batch_data = {
                "id": current_batch_id,  
                "video_name": video_clip_name,
                "start_frame_name": os.path.basename(batch_paths[0]),
                "final_s": float(final_s),
                "frames": []
            }

            camera_positions_meter = []
            intrinsic_matrices = []
            extrinsic_matrices = []

            for p in batch_paths:
                image_name = os.path.basename(p)
                targets = img2items.get(image_name, [])

                r = res[p]
                vis = r["vis"]
                PM = r["pointmap"]
                E = r["E"]
                K = r["K"]
                H, W = vis.shape[:2]

                R = E[:, :3]
                t = E[:, 3]
                C_world = -R.T @ t
                C_meter = C_world * final_s
                camera_positions_meter.append(C_meter.tolist())
                intrinsic_matrices.append(K.tolist())
                E_4x4 = np.eye(4)
                E_4x4[:3, :] = E
                extrinsic_matrices.append(E_4x4.tolist())

                frame_targets = []
                if targets:
                    bboxes_xyxy = [bbox_xyxy_from_norm(t["bbox"], W, H) for t in targets]
                    keep_indices = filter_bboxes_by_overlap_and_size(
                        bboxes_xyxy, H * W, BBOX_OVERLAP_THRESHOLD, BBOX_SIZE_THRESHOLD
                    )
                    filtered_targets = [targets[i] for i in keep_indices]
                    
                    for t in filtered_targets:
                        mask_data = self.process_one_target(vis, PM, E, K, t, s_frame=final_s)
                        if mask_data is not None:
                            frame_targets.append({
                                "object_id": mask_data["object_id"],
                                "label": mask_data["label"],
                                "bbox_2d_norm": mask_data["bbox_2d_norm"],
                                "distance_to_ego_m": mask_data["distance_to_ego_m"],
                                "azimuth_angle_deg": mask_data["azimuth_angle_deg"],
                                "mask_area_px": mask_data["mask_area_px"],
                                "scale_info": mask_data["scale_info"]
                            })

                frame_data = {
                    "image_name": image_name,
                    "s_frame": final_s,
                    "camera_height_m": CAM_HEIGHT_M,
                    "targets": frame_targets,
                    "inter_target_distances": []
                }
                batch_data["frames"].append(frame_data)

            if len(camera_positions_meter) == 10:
                origin = np.array(camera_positions_meter[3])
                history_traj = [((np.array(p) - origin).tolist()) for p in camera_positions_meter[:3]]
                future_traj = [((np.array(p) - origin).tolist()) for p in camera_positions_meter[3:]]
                
                batch_data["intrinsic_matrix"] = intrinsic_matrices[0]
                batch_data["extrinsic_matrix"] = extrinsic_matrices
                batch_data["history_traj"] = history_traj
                batch_data["future_traj"] = future_traj

            batch_path = os.path.join(out_dir, f"batch_{current_batch_id:03d}.json") 
            with open(batch_path, 'w', encoding='utf-8') as f:
                json.dump(batch_data, f, indent=2, ensure_ascii=False)

            self.total_saved_batches += 1
            self.total_processed_frames += len(batch_paths)

            del res, batch_data, camera_positions_meter, intrinsic_matrices, extrinsic_matrices
            gc.collect()
            if torch.cuda.is_available():
                torch.cuda.empty_cache()

        print(f"[CLIP DONE] {scene_name}/{video_clip_name}: saved {self.total_saved_batches} batches")

    def get_existing_batches_global(self) -> set:
        existing_batches = set()
        for scene in SCENE_LIST:
            scene_output_dir = os.path.join(OUTPUT_ROOT, scene)
            if not os.path.exists(scene_output_dir):
                continue

            for video_clip in os.listdir(scene_output_dir):
                video_clip_dir = os.path.join(scene_output_dir, video_clip)
                if not os.path.isdir(video_clip_dir):
                    continue
                    
                for f in os.listdir(video_clip_dir):
                    if f.startswith("batch_") and f.endswith(".json"):
                        try:
                            batch_num = int(f.split("_")[1].split(".")[0])
                            existing_batches.add(batch_num)
                        except ValueError:
                            continue
        return existing_batches

    def process_scene(self, scene_name: str):
        scene_image_dir = os.path.join(IMAGE_ROOT, scene_name)
        if not os.path.isdir(scene_image_dir):
            print(f"[SKIP] 场景不存在: {scene_image_dir}")
            return
        video_clip_dirs = subdirs(scene_image_dir)
        print(f"[SCENE] {scene_name}: video_clips={len(video_clip_dirs)}")
        for vdir in video_clip_dirs:
            self.process_video_clip(scene_name, vdir)

    def run(self):
        os.makedirs(OUTPUT_ROOT, exist_ok=True)
        for scene in SCENE_LIST:
            print(f"\n=== Processing Scene: {scene} ===")
            self.process_scene(scene)
        print(f"\n[ALL DONE] Total saved batches: {self.total_saved_batches}")


def main():
    processor = BatchProcessor(VGGT_WEIGHTS_DIR)
    processor.run()

if __name__ == "__main__":
    main()