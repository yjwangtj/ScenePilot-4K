import os
import re
import json
import argparse
from pathlib import Path
from collections import defaultdict
from typing import Any, Dict, List, Optional


def _norm(text: Any) -> str:
    if text is None:
        return ""
    if not isinstance(text, str):
        text = str(text)
    text = text.lower().strip()
    text = text.replace("’", "'").replace("“", '"').replace("”", '"')
    text = re.sub(r"\s+", " ", text)
    return text

# 根据参考答案(GT)内容判断问题类型
def detect_q_type_by_gt(gt_answer: str) -> Optional[str]:

    if not gt_answer:
        return None
    g = _norm(gt_answer)

    # 先处理角度类，防止被其他 Q 误判 
    # Q22: 绝对方向
    if "degrees" in g and any(
        k in g
        for k in [
            "absolute heading",
            "bearing from",
            "direction from the",
            "from the first",
            "from the first object",
            "looking from the first",
        ]
    ):
        return "Q22"

    # Q21: 方位角差
    if "degrees" in g and any(
        k in g
        for k in [
            "azimuthal difference",
            "angular offset",
            "differ in azimuth",
            "degrees apart",
            "bearing directions",
            "azimuthal separation",
        ]
    ):
        return "Q21"

    #  Q20 放在角度类后 
    dist_phrase = re.compile(r"\b\d+(\.\d+)?\s*[-\s]?(m|meter|meters)\b", re.I)
    if dist_phrase.search(g) and any(
        k in g
        for k in [
            "their distance",
            "distance between",
            "meters apart",
            "separation between",
            "meter gap",
            "apart",
        ]
    ):
        return "Q20"

    if any(
        k in g
        for k in ["weather", "sunny", "daytime", "night", "road type", "lane", "rural"]
    ):
        return "Q14"

    if "intersection" in g:
        return "Q13"

    if (
        "one second" in g
        or "1 second" in g
        or "one-second-ahead" in g
        or "+1s" in g
        or "one-second" in g
    ):
        return "Q17"
    if (
        "two seconds" in g
        or "2 seconds" in g
        or "two-second-ahead" in g
        or "+2s" in g
        or "two-second" in g
    ):
        return "Q18"
    if (
        "three seconds" in g
        or "3 seconds" in g
        or "three-second-ahead" in g
        or "+3s" in g
        or "three-second" in g
    ):
        return "Q19"

    if any(
        k in g
        for k in [
            "based on where",
            "extrapolating",
            " from past poses",
            "history motion",
            "the vehicle has been moving",
            "motion history",
        ]
    ):
        return "Q16"

    if any(
        k in g
        for k in [
            "trajectory",
            "path",
            "expected to follow",
            " route",
            "forecast",
            "anticipated motion",
        ]
    ):
        return "Q15"

    if (
        "risk level" in g
        or re.search(r"\b(low|medium|high)\s+risk\b", g)
        or ("risk" in g and "meters" not in g)
    ):
        return "Q12"

    if ("15 meter" in g or "within 15" in g or "15-meter mark" in g) and ("degree" not in g and "degrees" not in g):
        return "Q8"

    if "mid-range" in g or "10 and 30" in g or "10 to 30" in g:
        return "Q9"

    if re.search(r"meters?", g) and "degrees" in g:
        return "Q1"

    if (
        any(
            k in g
            for k in [
                "riskier",
                "hazard",
                "hazardous",
                "threat",
                "concern",
                "collision",
            ]
        )
        and "meters" in g
    ):
        return "Q11"

    if any(k in g for k in ["normalized", "center", "width", "height", "bounding box"]):
        return "Q3"

    if any(k in g for k in ["nearest", "closest", "object closest"]):
        return "Q4"

    if any(
        k in g
        for k in [
            "notable",
            "targets",
            "include",
            "participants",
            "key participants",
            "distinct objects",
        ]
    ):
        return "Q5"

    if any(
        k in g
        for k in ["closer", "farther", "difference", "differs by", "separated by"]
    ):
        return "Q6"

    if any(k in g for k in ["pedestrian", "people", "pedestrians"]) and any(
        k in g for k in ["bicycle", "bike", "cyclist", "bicycles"]
    ):
        return "Q7"

    if (
        any(k in g for k in ["truck", "it’s", "it is", "we see the truck"])
        and any(k in g for k in ["side", "left", "right"])
        and not any(k in g for k in ["than", "both", "same", "opposite", "while"])
    ):
        return "Q2"

    if any(
        k in g
        for k in [
            "same side",
            "opposite side",
            "both on the",
            "on the same side",
            "on opposite sides",
            "located on the",
        ]
    ) or (" is on the " in g and " while the " in g):
        return "Q10"

    return None

#根据问题内容判断问题类型
def detect_q_type(question: str) -> Optional[str]:

    q = _norm(question)
    if not q:
        return None

    # 先角度类，防止被 Q6/Q1 误判 
    if (
        "absolute heading" in q
        or "bearing from" in q
        or "which direction" in q
        or "located" in q
    ):
        return "Q22"

    if any(
        k in q
        for k in [
            "azimuthal difference",
            "angular offset",
            "degrees apart",
            "azimuth",
            "bearing directions",
            "differ in azimuth",
        ]
    ):
        return "Q21"

    if any(
        k in q
        for k in [
            "distance between",
            "apart",
            "separation between",
            "distance in meters",
            "how far",
            "how many meters apart",
        ]
    ):
        return "Q20"

    if any(
        k in q for k in ["bbox", "normalized", "bounding box", "(cx", "width", "height"]
    ):
        return "Q3"

    if re.search(r"\bt\+1s\b", q) or "1 second" in q or "one second" in q or "+1s" in q:
        return "Q17"
    if (
        re.search(r"\bt\+2s\b", q)
        or "2 seconds" in q
        or "two seconds" in q
        or "+2s" in q
    ):
        return "Q18"
    if (
        re.search(r"\bt\+3s\b", q)
        or "3 seconds" in q
        or "three seconds" in q
        or "+3s" in q
    ):
        return "Q19"

    if any(
        k in q
        for k in [
            "mid-range",
            "middle",
            "within",
            "between",
            "medium",
            "range band",
            "interval",
            "bounded",
            "bracket",
        ]
    ):
        return "Q9"

    if (
        "within" in q
        or "closer than" in q
        or "nearer than" in q
        or "less than" in q
        or "under" in q
        or "minimum ego-distance" in q
        or "[threshold_m]" in q
        or "<" in q
        or re.search(r"(within|under|below|less than|<)\s*\d+(\.\d+)?\s*m", q)
        or re.search(r"nearer than\s*\d+(\.\d+)?\s*m", q)
    ):
        return "Q8"

    if (
        all(k in q for k in ["weather", "road", "lane"])
        and any(k in q for k in ["time", "day", "night"])
        and "difference" not in q
    ):
        return "Q14"

    if any(k in q for k in ["closest", "nearest", "minimum-range"]):
        return "Q4"

    if any(
        k in q
        for k in [
            "difference",
            "closer",
            "farther",
            "compare",
            "distance gap",
            "range offset",
            "separation in meters",
            "how many meters separate",
            "disparity",
        ]
    ):
        return "Q6"

    if any(
        k in q for k in ["azimuth", "bearing", "angle", "radial", "direction"]
    ) or any(k in q for k in ["distance", "range", "meters", "separation"]):
        if not any(
            k in q
            for k in [
                "difference",
                "closer",
                "farther",
                "compare",
                "versus",
                "vs",
                "closest",
                "nearest",
                "gap",
            ]
        ):
            return "Q1"

    if "same side" in q or "co-lateral" in q or re.search(r"both .* side", q):
        return "Q10"

    if any(k in q for k in ["left", "right", "front"]) and (
        "side" in q or "lateral" in q
    ):
        return "Q2"

    if any(k in q for k in ["how many", "count", "number of", "total"]):
        return "Q5"

    if any(k in q for k in ["pedestrian", "bicycle", "cyclist"]) and any(
        k in q for k in ["any", "present", "exist", "scene contain"]
    ):
        return "Q7"

    if any(k in q for k in ["collision risk", "hazard", "threat", "danger"]):
        return "Q11"

    if "risk level" in q or "risk rating" in q:
        return "Q12"

    if "intersection" in q or "junction" in q or "crossroad" in q:
        return "Q13"

    if "history" in q or "[history_traj]" in q:
        return "Q16"

    if any(k in q for k in ["predict", "forecast", "future trajectory", "ego path"]):
        return "Q15"

    return None


def extract_question(sample: Dict[str, Any]) -> str:

    # 格式1：messages
    messages = sample.get("messages")
    if isinstance(messages, list):
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "user":
                content = msg.get("content", "")
                if content:
                    return str(content)

    # 格式2：扁平字段
    candidates = [
        "question",
        "Question",
        "query",
        "instruction",
        "prompt",
        "input",
    ]
    for key in candidates:
        if key in sample and sample[key]:
            return str(sample[key])

    return ""

def extract_gt_answer(sample: Dict[str, Any]) -> str:

    # 格式1：messages
    messages = sample.get("messages")
    if isinstance(messages, list):
        for msg in messages:
            if isinstance(msg, dict) and msg.get("role") == "assistant":
                content = msg.get("content", "")
                if content:
                    return str(content)

    # 格式2：扁平字段
    candidates = [
        "gt_answer",
        "GT_answer",
        "gt",
        "answer",
        "Answer",
        "target",
        "label",
        "output",
        "response",
    ]

    for key in candidates:
        if key in sample and sample[key] is not None:
            value = sample[key]
            if isinstance(value, list):
                return " ".join(str(v) for v in value)
            return str(value)

    if "answers" in sample and sample["answers"] is not None:
        value = sample["answers"]
        if isinstance(value, list):
            return " ".join(str(v) for v in value)
        return str(value)

    return ""


def classify_sample(sample: Dict[str, Any]) -> str:
    """
    分类优先级：
    1. 先用 GT answer
    2. 再用 question
    3. 最后 UNKNOWN
    """
    gt_answer = extract_gt_answer(sample)
    q_type = detect_q_type_by_gt(gt_answer)
    if q_type:
        return q_type

    question = extract_question(sample)
    q_type = detect_q_type(question)
    if q_type:
        return q_type

    return "UNKNOWN"


def load_json(input_path: str) -> List[Dict[str, Any]]:
    with open(input_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    if isinstance(data, list):
        return data

    if isinstance(data, dict):
        if "data" in data and isinstance(data["data"], list):
            return data["data"]
        if "annotations" in data and isinstance(data["annotations"], list):
            return data["annotations"]
        if "items" in data and isinstance(data["items"], list):
            return data["items"]

    raise ValueError("Unsupported JSON format. Expect list or dict containing a list.")


def save_json(data: Any, output_path: str) -> None:
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def summarize_counts(grouped: Dict[str, List[Dict[str, Any]]]) -> Dict[str, int]:
    return {k: len(v) for k, v in sorted(grouped.items(), key=lambda x: x[0])}


def filter_qtypes(
    grouped: Dict[str, List[Dict[str, Any]]], keep_qtypes: List[str]
) -> Dict[str, List[Dict[str, Any]]]:
    keep_set = set(keep_qtypes)
    return {k: v for k, v in grouped.items() if k in keep_set}


def classify_dataset(
    samples: List[Dict[str, Any]], add_qtype_field: bool = True
) -> Dict[str, List[Dict[str, Any]]]:
    grouped: Dict[str, List[Dict[str, Any]]] = defaultdict(list)

    for idx, sample in enumerate(samples):
        if not isinstance(sample, dict):
            sample = {"raw": sample}

        q_type = classify_sample(sample)

        if add_qtype_field:
            sample = dict(sample)
            sample["q_type"] = q_type
            sample["q_id"] = q_type

        grouped[q_type].append(sample)

        if (idx + 1) % 1000 == 0:
            print(f"Processed {idx + 1} samples...")

    return grouped


def main():
    parser = argparse.ArgumentParser(
        description="Classify VQA samples into Q1~Q22 using GT-first rules."
    )
    parser.add_argument(
        "--input", type=str, required=True, help="Path to input JSON file"
    )
    parser.add_argument(
        "--output_dir",
        type=str,
        required=True,
        help="Directory to save classification outputs",
    )
    parser.add_argument(
        "--keep_qtypes",
        type=str,
        default="",
        help="Comma-separated qtypes to keep, e.g. Q1,Q6,Q10,Q11",
    )
    parser.add_argument(
        "--save_per_class", action="store_true", help="Save one JSON file per class"
    )
    parser.add_argument(
        "--save_all",
        action="store_true",
        help="Save one merged JSON containing all classified samples",
    )
    parser.add_argument(
        "--unknown_only",
        action="store_true",
        help="Only save UNKNOWN samples for manual inspection",
    )
    args = parser.parse_args()

    samples = load_json(args.input)
    print(f"Loaded {len(samples)} samples from {args.input}")

    grouped = classify_dataset(samples, add_qtype_field=True)

    if args.keep_qtypes.strip():
        keep_qtypes = [x.strip() for x in args.keep_qtypes.split(",") if x.strip()]
        grouped = filter_qtypes(grouped, keep_qtypes)

    if args.unknown_only:
        grouped = {"UNKNOWN": grouped.get("UNKNOWN", [])}

    os.makedirs(args.output_dir, exist_ok=True)

    counts = summarize_counts(grouped)
    print("Classification summary:")
    for k, v in counts.items():
        print(f"  {k}: {v}")

    summary_path = os.path.join(args.output_dir, "summary.json")
    save_json(counts, summary_path)
    print(f"Saved summary to {summary_path}")

    if args.save_per_class:
        for q_type, items in grouped.items():
            out_path = os.path.join(args.output_dir, f"{q_type}.json")
            save_json(items, out_path)
        print(f"Saved per-class files to {args.output_dir}")

    if args.save_all:
        merged = []
        for _, items in grouped.items():
            merged.extend(items)
        out_path = os.path.join(args.output_dir, "classified_all.json")
        save_json(merged, out_path)
        print(f"Saved merged file to {out_path}")


if __name__ == "__main__":
    main()
