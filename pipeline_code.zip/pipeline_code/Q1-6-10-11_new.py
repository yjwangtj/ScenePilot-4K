
import os
import json
import random
import glob

SCENE_IDS = [
    "xxx"#文件夹名称
]

INPUT_YIPI_ROOT = "your VGGT path"
INPUT_SCENE_DESC_ROOT = "your scene_description path"
OUTPUT_CHAT_ROOT = "your output path"
DATASET_ROOT = "your images path" 

MIN_VALID_RATIO = 0


def ref(obj):
    return f"Region [{obj.get('object_id','0')}]"

VQA_TEMPLATES = {
    "Q1": [line.strip() for line in """
        How far is the [CLASS] from the ego vehicle, and what is its azimuth?
        For the [CLASS] located, report ego-relative range and bearing (°).
        Provide the distance (m) and azimuth angle (°) of the [CLASS].
        What is the straight-line range to the [CLASS] and its bearing?
        Return the ego-centric distance and heading angle for the [CLASS].
        Give the radial distance and azimuth (degrees) of the [CLASS] positioned.
        Compute the ego-to-object range and azimuth for the [CLASS] with location [LOC].
        What are the range (m) and direction (° from ego) of the [CLASS]?
        Report the Euclidean distance and relative angle to the [CLASS].
        Specify distance and azimuthal bearing of the [CLASS] found.
        Determine the separation (m) and heading (°) to the [CLASS].
        What ego-relative range and azimuth does the [CLASS] have?
        Provide the straight-line separation and azimuth for the [CLASS].
        Output range-to-ego and bearing angle for the [CLASS] located.
        Report how many meters away and at what azimuth the [CLASS] lies.
        Give the range and compass-like bearing (°) to the [CLASS].
        Return the distance and ego-relative direction angle for the [CLASS].
        What is the radial offset (m) and azimuth (°) from ego to the [CLASS]?
        Provide ego-object range and angular bearing for the [CLASS] specified by [LOC].
        Quantify the distance and azimuthal orientation of the [CLASS] appearing.
        """.strip().split('\n')],
    
    "Q2": [
        "On which side of the ego vehicle is the truck located?",
        "Is the truck to the left or right of the ego vehicle?",
        "Indicate the ego-relative side where the truck appears (left/right/ahead).",
        "Relative to ego, where is the truck positioned (left/right/front)?",
        "Identify the truck’s lateral side with respect to the ego vehicle.",
        "Specify whether the truck lies on the left or right side of ego.",
        "Which lateral half (left/right) contains the truck relative to ego?",
        "Report the truck’s side-of-ego classification (left/right/other).",
        "Does the truck appear on the driver’s left or right when viewed from ego?",
        "Determine whether the truck is left-of-ego, right-of-ego, or centered ahead.",
        "Where does the truck fall laterally with respect to the ego vehicle?",
        "Indicate the truck’s position: left side, right side, or directly ahead of ego.",
        "Assign the truck to a lateral side relative to ego (left/right).",
        "Is the truck observed on ego’s left, on ego’s right, or in front?",
        "Classify the truck’s ego-relative lateral placement (left/right/front-right, etc.).",
        "Which side descriptor best matches the truck’s location relative to ego?",
        "Provide the truck’s lateral relation to ego (e.g., left/right/front-left).",
        "State whether the truck sits left or right of the ego vehicle.",
        "Identify whether the truck’s position is on the near-left, near-right, or centerline.",
        "Label the truck’s side with respect to ego: [SIDE]."
    ],
    "Q3": [
        "In [IMAGE_NAME], what are the normalized center (cx, cy) and size (w, h) of the [CLASS] bbox?",
        "Provide the [CLASS] bbox centroid (cx, cy) and dimensions (w, h), normalized.",
        "Report the normalized (cx, cy, w, h) for the [CLASS] in [IMAGE_NAME].",
        "Return the [CLASS] bounding box center and width/height in normalized units.",
        "What is the normalized center point and box size of the [CLASS] in [IMAGE_NAME]?",
        "Give (cx, cy, w, h), normalized to image size, for the [CLASS] bbox.",
        "Provide the normalized center coordinates and extents (w, h) of the [CLASS] box.",
        "Output the [CLASS] bbox centroid and normalized width/height.",
        "Specify the normalized bbox parameters (cx, cy, w, h) for [CLASS].",
        "Report normalized center and box dimensions for [CLASS] in [IMAGE_NAME].",
        "Return the normalized 2D box center and size of the [CLASS].",
        "Provide the centroid (normalized) and size metrics for [CLASS]’s bbox.",
        "What are the normalized bbox center coordinates and side lengths for [CLASS]?",
        "Deliver normalized (cx, cy) and (w, h) for the [CLASS] bounding box.",
        "State the normalized box center and width/height for [CLASS].",
        "Provide normalized center and scale (w, h) for [CLASS] in [IMAGE_NAME].",
        "Return normalized box centroid and dimension tuple for [CLASS].",
        "Report normalized center-of-box and size for the [CLASS] instance.",
        "Give normalized bbox stats: center=(cx, cy), size=(w, h) for [CLASS].",
        "Provide the normalized geometry (cx, cy, w, h) of [CLASS]’s 2D bounding box."
    ],
    "Q4": [
        "Which object is closest to the ego vehicle, and what is its distance?",
        "Identify the nearest object class and its range to ego.",
        "What class is the closest object, and how far away is it (m)?",
        "Name the closest traffic participant and report the distance.",
        "Provide the type of the nearest target and its ego-relative range.",
        "Which actor lies nearest to ego, and at what distance?",
        "Report the closest object category and measured range to ego.",
        "Determine the nearest participant and specify distance (meters).",
        "Who is the closest object to ego? Return its class and distance.",
        "Give the class label and distance of the closest entity.",
        "State which object is nearest and its separation from ego.",
        "Identify the minimum-range object and provide its distance.",
        "Which detected class has the lowest ego-distance? Report the value.",
        "Provide the nearest object type along with its range estimate.",
        "What is the closest target and how many meters away is it?",
        "Return the nearest participant’s class and ego-distance.",
        "Specify which object is closest in range and its distance (m).",
        "Indicate the nearest actor and the corresponding distance to ego.",
        "Which object has minimal separation from ego? Provide distance.",
        "Report the nearest-object label and its range."
    ],
    "Q5": [
        "How many notable traffic participants are present, and what are their types?",
        "Report the count of key objects and enumerate their classes.",
        "How many salient actors are in view? List each by type.",
        "Provide the total number of prominent objects and specify their categories.",
        "Count the noteworthy participants and list their labels.",
        "Return a tally of major actors and their class names.",
        "How many targets are detected? Enumerate the class of each.",
        "Supply the object count and a type list for all notable participants.",
        "Report the number of significant objects and their categories.",
        "Provide a count of salient entities and list their classes.",
        "How many important actors appear, and what are their labels?",
        "Return the total targets and a breakdown by type.",
        "Count all key participants and enumerate their classes.",
        "Give the quantity of prominent objects and their class set.",
        "Provide the count of detected actors and their type names.",
        "How many central participants exist? List each category.",
        "Report object cardinality and class labels for notable targets.",
        "Return both the count and class inventory of salient objects.",
        "Provide the number of visible key actors and their object classes.",
        "Tally the notable participants and present their types."
    ],
    "Q6": [
        "What is the difference in distance between the [CLASS_A] and the [CLASS_B]?",
        "How much closer or farther is the [CLASS_A] compared to the [CLASS_B]?",
        "Compute the absolute distance gap between the [CLASS_A] and the [CLASS_B].",
        "Report the ego-distance difference (in meters) between the [CLASS_A] and the [CLASS_B].",
        "Provide the range offset between the [CLASS_A] and the [CLASS_B].",
        "What is the separation in meters between the [CLASS_A] and the [CLASS_B]?",
        "Return how many meters separate the [CLASS_A] from the [CLASS_B] in terms of ego distance.",
        "Give the distance difference between the [CLASS_A] side and the [CLASS_B].",
        "State the ego-relative distance disparity between the [CLASS_A] and the [CLASS_B].",
        "Quantify how much nearer/farther the [CLASS_A] is than the [CLASS_B]."
    ],
    "Q7": [
        "Does the scene contain any pedestrians or bicycles?",
        "Are there pedestrians and/or cyclists present in the frame?",
        "Indicate whether pedestrian or bicycle classes are visible.",
        "Do we observe any people-on-foot or bicycles in this image?",
        "Check if pedestrians or cyclists appear in the scene.",
        "Report whether pedestrian/bicycle categories are detected.",
        "Are any walking persons or bikes present?",
        "Is there at least one pedestrian or one bicycle visible?",
        "Confirm the presence/absence of pedestrians or cyclists.",
        "State whether the frame includes pedestrians or bicycles.",
        "Are pedestrian or cyclist instances detected?",
        "Does the image show any foot traffic or bicycles?",
        "Indicate if human-on-foot or bicycle participants exist here.",
        "Are there any cyclist or pedestrian objects in view?",
        "Return a yes/no on pedestrians or bikes appearing.",
        "Verify the existence of pedestrian/bicycle actors in this frame.",
        "Are pedestrian/cycle classes present among detections?",
        "Do pedestrians or bicycles occur in the current scene?",
        "Is either a pedestrian or a cyclist visible in this image?",
        "Report if the scene includes pedestrians and/or bicycles."
    ],
    "Q8": [
        "Is any object closer than [THRESHOLD_M] meters to the ego vehicle?",
        "Are there targets whose ego-distance is < [THRESHOLD_M] m?",
        "Determine whether any participant lies within [THRESHOLD_M] m of ego.",
        "Report if any object is inside the [THRESHOLD_M]-meter range.",
        "Does the scene include objects nearer than [THRESHOLD_M] m?",
        "Check for the presence of targets within [THRESHOLD_M] meters.",
        "Is there at least one actor inside the [THRESHOLD_M] m radius?",
        "Confirm whether any object violates the [THRESHOLD_M] m proximity.",
        "Are any participants located within [THRESHOLD_M] m of the ego car?",
        "Provide a yes/no on objects inside the [THRESHOLD_M] m threshold.",
        "Do any detections fall under the [THRESHOLD_M] m distance limit?",
        "Indicate if the minimum ego-distance is below [THRESHOLD_M] m.",
        "Are there close-range actors (within [THRESHOLD_M] meters)?",
        "Verify if any object lies at a range less than [THRESHOLD_M] m.",
        "Is the closest object nearer than [THRESHOLD_M] meters?",
        "Do we have participants present within a [THRESHOLD_M] m band?",
        "Is the near-field (≤[THRESHOLD_M] m) populated by any objects?",
        "Determine whether any entity is closer than [THRESHOLD_M] m.",
        "Report if the near-range threshold [THRESHOLD_M] m is breached by any object.",
        "Are there actors whose separation to ego is inside [THRESHOLD_M] m?"
    ],
    "Q9": [
        "Is the truck at [BBOX_NORM]/[TARGET_ID] within [RANGE_MIN_M]–[RANGE_MAX_M] meters?",
        "Does the specified truck fall inside the mid-range distance interval?",
        "Verify whether that truck lies between [RANGE_MIN_M] and [RANGE_MAX_M] m.",
        "Check if the truck is in the medium-distance zone ([RANGE_MIN_M]–[RANGE_MAX_M] m).",
        "Determine if the truck qualifies as “mid-range” under these bounds.",
        "Is the referenced truck’s ego-distance within the mid-range bracket?",
        "Does the truck’s range lie in the specified middle band of distances?",
        "Confirm whether the truck is in the [RANGE_MIN_M]–[RANGE_MAX_M] m window.",
        "Assess if the truck is inside the defined mid-range interval.",
        "Report whether the truck distance falls within the mid-range bounds.",
        "Is that truck considered mid-range given [RANGE_MIN_M]/[RANGE_MAX_M]?",
        "Indicate if the truck’s separation lies in the medium band.",
        "Does the truck’s measured range sit within the specified mid-range span?",
        "Verify that the truck is not below [RANGE_MIN_M] nor above [RANGE_MAX_M] m.",
        "Check inclusion of the truck’s distance in the mid-range set.",
        "Determine if the truck belongs to the mid-range category.",
        "Provide a yes/no on the truck being in the mid-distance band.",
        "Is the truck’s ego-range bounded by [RANGE_MIN_M] and [RANGE_MAX_M] m?",
        "Confirm mid-range membership for the truck given the limits.",
        "State whether the truck falls into the medium-distance interval."
    ],
    "Q10": [
        "Are the [CLASS_A] and the [CLASS_B] on the same side of the ego vehicle?",
        "Do the [CLASS_A] and [CLASS_B] lie on the same lateral side relative to the ego?",
        "Is the [CLASS_A] located on the same side as the [CLASS_B]?",
        "Are both the [CLASS_A] and the [CLASS_B] on the left, both on the right, or on opposite sides?",
        "Check whether the [CLASS_A] and the [CLASS_B] share the same ego-relative side.",
        "Does the [CLASS_A] appear on the same lateral half as the [CLASS_B]?",
        "Are the [CLASS_A] and [CLASS_B] co-lateral (e.g., both left or both right) with respect to ego?",
        "Do the [CLASS_A] and [CLASS_B] occupy the same side category (left/right/front)?",
        "Is the lateral position of the [CLASS_A] identical to that of the [CLASS_B]?",
        "Confirm if the [CLASS_A] and the [CLASS_B] are on the same side of the road from ego’s view.",
        "Are the two objects — the [CLASS_A] and the [CLASS_B] — on the same side?",
        "Determine if the [CLASS_A] and [CLASS_B] are both left-of-ego, both right-of-ego, or split.",
        "Do the [CLASS_A] and [CLASS_B] fall into the same lateral zone (left/right/ahead)?",
        "Is there lateral alignment between the [CLASS_A] and the [CLASS_B]?",
        "Are the [CLASS_A] and [CLASS_B] positioned on identical sides relative to the ego vehicle?",
        "Does the [CLASS_A] share its side (e.g., left/right) with the [CLASS_B]?",
        "Are the [CLASS_A] side and the [CLASS_B] laterally consistent?",
        "Verify if both the [CLASS_A] and [CLASS_B] are on the same ego-relative side.",
        "Is the side assignment of the [CLASS_A] the same as that of the [CLASS_B]?",
        "Do the [CLASS_A] and [CLASS_B] appear on the same lateral side from the ego vehicle’s perspective?"
    ],
    "Q11": [
        "Which target poses the greater collision risk to the ego vehicle, and why?",
        "Identify the higher-risk object and explain contributing factors.",
        "Which participant represents the larger collision hazard? Justify.",
        "Select the object with higher collision risk and state reasons.",
        "Of the candidates, who is riskier for ego? Provide rationale.",
        "Determine the more dangerous target and support your answer.",
        "Which actor has the higher collision likelihood? Explain.",
        "Identify the primary collision threat and describe why.",
        "Which object is most hazardous to ego? Give justification.",
        "Choose the higher-risk participant and explain the assessment.",
        "Which target presents the greatest immediate risk? Why?",
        "Indicate the riskier object and outline the key risk factors.",
        "Who constitutes the dominant collision risk? Explain briefly.",
        "Decide which entity is riskier and defend the choice.",
        "Which object poses higher danger to ego? Provide reasons.",
        "Name the target with elevated collision risk and explain.",
        "Which participant warrants more caution? Justify your pick.",
        "Identify the object with the greater risk profile and explain.",
        "Which actor is more likely to collide with ego? Why?",
        "Determine the higher-risk object and summarize the rationale."
    ],
    "Q12": [
        "What is the overall risk level of this scene?",
        "Assess the scene’s risk rating (e.g., low/medium/high).",
        "Provide the risk classification for the current scenario.",
        "How would you rate the scenario’s risk level?",
        "Report the risk tier that best describes the scene.",
        "Classify the scene’s risk severity.",
        "Assign a qualitative risk label to the scene.",
        "Indicate the risk level for the given frame.",
        "Provide a risk score or bucket for the scene.",
        "Rate the scenario’s risk on the chosen scale.",
        "Summarize the scene’s overall safety risk.",
        "Estimate the collision risk level of the scene.",
        "Return the scene’s risk category.",
        "Provide a high-level risk assessment for this context.",
        "Identify the appropriate risk band for the scene.",
        "Which risk tier fits this scenario?",
        "Give the scene’s risk evaluation (qualitative or numeric).",
        "Provide your risk judgment for the current scene.",
        "What risk label should be assigned here?",
        "Rate the scene’s risk intensity."
    ],
    "Q13": [
        "Is this scenario occurring at an intersection?",
        "Does the current scene depict an intersection?",
        "Indicate whether the scene constitutes an intersection.",
        "Is the roadway context an intersection in this case?",
        "Determine if the scene should be labeled “intersection.”",
        "Classify the scene as intersection vs. non-intersection.",
        "Is there an intersection present in this frame?",
        "Does the view show an intersection geometry?",
        "Are we at or approaching an intersection?",
        "Label the scene: intersection or not.",
        "Is the ego vehicle positioned within an intersection?",
        "Identify whether the layout corresponds to an intersection.",
        "Provide a yes/no on intersection presence.",
        "Does road topology indicate an intersection here?",
        "Is the scene captured at a crossroads/junction?",
        "Confirm whether this is an intersection scenario.",
        "Should this frame be tagged as intersection?",
        "Is this location a junction (intersection) or a straight road?",
        "Return intersection vs. non-intersection for this scene.",
        "Indicate if the scene belongs to the intersection class."
    ],
    
    "Q14": [line.strip() for line in """
        What are the weather, time of day, road type, number of lanes, intersection status, and risk level in this scene?
        Describe the scene in terms of weather, time, road type, lane count, whether it is an intersection, and risk level.
        Provide the weather condition, time of day, road type, number of lanes, intersection presence, and risk classification.
        State the weather, daytime/nighttime, road type, lane number, intersection status, and risk level.
        Report the current weather, time, road type, how many lanes, if it’s an intersection, and the risk level.
        What is the weather like, is it day or night, what type of road is this, how many lanes does it have, is it an intersection, and what is the risk level?
        Give the weather, time of day, road type, lane count, intersection flag, and risk level for this frame.
        Summarize the scene using: weather, time, road type, number of lanes, intersection (yes/no), and risk level.
        List the following: weather, time of day, road type, lanes, intersection status, and risk level.
        Characterize the scene by its weather, time of day, road type, lane count, whether it’s an intersection, and risk level.
        What are the six key attributes: weather, time, road type, lane number, intersection, and risk level?
        Describe only the weather, time of day, road type, number of lanes, intersection status, and risk level.
        Provide a factual summary of: weather, time, road type, lanes, intersection, and risk.
        What does the scene say about weather, time, road type, lane count, intersection, and risk?
        Extract the meta weather, time, road type, number of lanes, intersection, and risk level.
        Report the environmental and contextual attributes: weather, time, road type, lanes, intersection, risk.
        State the scene’s static attributes: weather, time of day, road type, lane count, intersection status, and risk level.
        What is the weather, is it day, what road type, how many lanes, is it an intersection, and what is the risk level?
        Give the six scene descriptors: weather, time, road type, lane number, intersection (yes/no), risk level.
        Describe the scene using only the provided meta weather, time, road type, lanes, intersection, risk.
        """.strip().split('\n')],
    
    "Q15": [
        "Based on road conditions and key object positions, predict the ego vehicle’s future trajectory.",
        "Using the scene context and critical actor locations, forecast ego’s path.",
        "Provide future ego trajectory points conditioned on roadway and salient targets.",
        "Predict ego motion considering current road geometry and nearby objects.",
        "Estimate the ego path leveraging target locations and road context.",
        "Generate a trajectory forecast for ego given the present layout.",
        "Output the predicted ego waypoints informed by scene context.",
        "Provide the ego’s future path under the current scene constraints.",
        "Forecast ego trajectory using road structure and actor placements.",
        "Return the anticipated ego track considering salient participants.",
        "Predict near-term ego motion paths from scene configuration.",
        "Provide a trajectory rollout conditioned on road and actors.",
        "Estimate ego’s path accounting for lanes, signals, and obstacles.",
        "Propose future ego waypoints guided by object geometry and lanes.",
        "Deliver a trajectory estimate given target states and road layout.",
        "Provide predicted ego positions based on contextual cues.",
        "Generate a path hypothesis considering surrounding objects.",
        "Forecast ego motion incorporating environmental constraints.",
        "Supply a sequence of future ego poses driven by scene context.",
        "Predict ego’s route segment under current roadway and traffic."
    ],
    
    "Q16": [line.strip() for line in """
        Based solely on the historical trajectory [HISTORY_TRAJ], predict the ego vehicle’s future path.
        Using only the past ego trajectory [HISTORY_TRAJ], forecast the upcoming path.
        Predict the ego’s future trajectory by extrapolating from its motion history [HISTORY_TRAJ].
        Given the historical ego track [HISTORY_TRAJ], estimate the next segment of the path.
        Forecast the ego vehicle’s future positions based on its prior trajectory [HISTORY_TRAJ].
        Project the ego’s path forward using only its historical motion data [HISTORY_TRAJ].
        Predict where the ego will go next, using only its past trajectory [HISTORY_TRAJ].
        From the historical trajectory [HISTORY_TRAJ] alone, infer the ego vehicle’s future route.
        Estimate the ego’s path leveraging only the recorded history: [HISTORY_TRAJ].
        Using the sequence of past ego positions [HISTORY_TRAJ], predict the next waypoints.
        Based on the ego’s movement history [HISTORY_TRAJ], forecast its future trajectory.
        Predict the ego’s path by extending its historical trajectory [HISTORY_TRAJ].
        Given the prior ego trajectory [HISTORY_TRAJ], what is the expected future path?
        Forecast the ego vehicle’s motion using only its historical path [HISTORY_TRAJ].
        Predict the next segment of the ego’s trajectory from its past positions [HISTORY_TRAJ].
        Using the ego’s historical poses [HISTORY_TRAJ], estimate its future locations.
        From the recorded history of ego motion [HISTORY_TRAJ], project the upcoming path.
        Predict the ego’s future track by extrapolating its historical data [HISTORY_TRAJ].
        Based on the ego’s past trajectory [HISTORY_TRAJ], where will it go next?
        Forecast the ego vehicle’s future path using only its motion history [HISTORY_TRAJ].
        """.strip().split('\n')],
    
    "Q17": [
        "What is the ego vehicle’s predicted position after 1 second?",
        "Where will the ego vehicle be located in 1 second?",
        "Provide the ego’s coordinates one second from now.",
        "What are the (x, y, z) coordinates of the ego vehicle at t+1s?",
        "Predict the ego’s location after one second of travel.",
        "Give the 3D position of the ego vehicle one second in the future.",
        "What is the ego’s future pose at the 1-second mark?",
        "Forecast the ego vehicle’s position at t+1s.",
        "After 1 second, where is the ego vehicle expected to be?",
        "Return the ego’s (x, y, z) position one second ahead.",
        "Estimate the ego’s location in 1 second.",
        "What will be the ego’s world coordinates after 1 second?",
        "Provide the predicted (x, y, z) of ego at +1s.",
        "One second from now, what is the ego’s position?",
        "Output the ego vehicle’s future coordinates at 1s.",
        "Where is the ego projected to be in 1 second?",
        "Give the 1-second-ahead pose of the ego vehicle.",
        "What is the ego’s anticipated location after 1 second?",
        "Predict the (x, y, z) position of ego at t+1s.",
        "After one second, what are the ego’s coordinates?"
    ],
    "Q18": [
        "What is the ego vehicle’s predicted position after 2 seconds?",
        "Where will the ego vehicle be located in 2 seconds?",
        "Provide the ego’s coordinates two seconds from now.",
        "What are the (x, y, z) coordinates of the ego vehicle at t+2s?",
        "Predict the ego’s location after two seconds of travel.",
        "Give the 3D position of the ego vehicle two seconds in the future.",
        "What is the ego’s future pose at the 2-second mark?",
        "Forecast the ego vehicle’s position at t+2s.",
        "After 2 seconds, where is the ego vehicle expected to be?",
        "Return the ego’s (x, y, z) position two seconds ahead.",
        "Estimate the ego’s location in 2 seconds.",
        "What will be the ego’s world coordinates after 2 seconds?",
        "Provide the predicted (x, y, z) of ego at +2s.",
        "Two seconds from now, what is the ego’s position?",
        "Output the ego vehicle’s future coordinates at 2s.",
        "Where is the ego projected to be in 2 seconds?",
        "Give the 2-second-ahead pose of the ego vehicle.",
        "What is the ego’s anticipated location after 2 seconds?",
        "Predict the (x, y, z) position of ego at t+2s.",
        "After two seconds, what are the ego’s coordinates?"
    ],
    "Q19": [
        "What is the ego vehicle’s predicted position after 3 seconds?",
        "Where will the ego vehicle be located in 3 seconds?",
        "Provide the ego’s coordinates three seconds from now.",
        "What are the (x, y, z) coordinates of the ego vehicle at t+3s?",
        "Predict the ego’s location after three seconds of travel.",
        "Give the 3D position of the ego vehicle three seconds in the future.",
        "What is the ego’s future pose at the 3-second mark?",
        "Forecast the ego vehicle’s position at t+3s.",
        "After 3 seconds, where is the ego vehicle expected to be?",
        "Return the ego’s (x, y, z) position three seconds ahead.",
        "Estimate the ego’s location in 3 seconds.",
        "What will be the ego’s world coordinates after 3 seconds?",
        "Provide the predicted (x, y, z) of ego at +3s.",
        "Three seconds from now, what is the ego’s position?",
        "Output the ego vehicle’s future coordinates at 3s.",
        "Where is the ego projected to be in 3 seconds?",
        "Give the 3-second-ahead pose of the ego vehicle.",
        "What is the ego’s anticipated location after 3 seconds?",
        "Predict the (x, y, z) position of ego at t+3s.",
        "After three seconds, what are the ego’s coordinates?"
    ]
}

ANSWER_TEMPLATES = {
    "Q1": [
        "The [CLASS] is about [DIST] meters away and sits at an angle of [AZIMUTH] degrees from our heading.",
        "We've got the [CLASS] roughly [DIST] meters out, bearing [AZIMUTH] degrees to the side.",
        "The distance to [CLASS] is [DIST] meters, and its bearing is [AZIMUTH] degrees.",
        "The [CLASS] is positioned [DIST] meters away, and it's offset by [AZIMUTH] degrees from straight ahead.",
        "You can see the [CLASS] [DIST] meters ahead (or to the side), with a direction of [AZIMUTH] degrees."
    ],
    "Q2": [
        "The truck is on the [SIDE].",
        "It’s sitting over on the [SIDE] side.",
        "From our perspective, the truck is clearly on the [SIDE].",
        "We see the truck off to the [SIDE].",
        "The truck appears on the [SIDE] relative to our position."
    ],
    "Q3": [
        "The bounding box is centered at ([CX], [CY]) and measures [W] in width and [H] in height, all in normalized image coordinates.",
        "In normalized terms, the object’s center is at ([CX], [CY]), and it spans [W] by [H].",
        "The box has a normalized center of ([CX], [CY]) with a width of [W] and height of [H].",
        "Its normalized center point is ([CX], [CY]), and the box is [W] units wide and [H] tall.",
        "Centered at ([CX], [CY]), the object occupies a normalized area of [W] by [H]."
    ],
    "Q4": [
        "The closest thing to us is a [CLASS], and it’s only [DIST] meters away.",
        "Nearest to the ego vehicle is a [CLASS], sitting just [DIST] meters out.",
        "The object closest to us is a [CLASS] at a distance of [DIST] meters.",
        "We’re closest to a [CLASS], which is [DIST] meters from our position.",
        "The nearest detected object is a [CLASS], and it’s [DIST] meters away."
    ],
    "Q5": [
        "We’ve detected [COUNT] objects in total, and they include [TYPES].",
        "There are [COUNT] notable objects visible: [TYPES].",
        "Altogether, [COUNT] key participants are present—specifically [TYPES].",
        "In the scene, we see [COUNT] distinct objects: [TYPES].",
        "The system picked up [COUNT] targets, which are [TYPES]."
    ],
    "Q6": [
        "The [CLASS_A] is [DIFF] meters [CLOSER_OR_FARTHER] than the [CLASS_B].",
        "There is a [DIFF]-meter distance difference: the [CLASS_A] is [CLOSER_OR_FARTHER] than the [CLASS_B].",
        "The ego-distance to the [CLASS_A] differs from that of the [CLASS_B] by [DIFF] meters, with the former being [CLOSER_OR_FARTHER].",
        "The [CLASS_B] is [DIFF] meters [CLOSER_OR_FARTHER_REVERSE] than the [CLASS_A].",
        "In terms of range, the [CLASS_A] and [CLASS_B] are separated by [DIFF] meters."
    ],
    "Q7": [
        "Yes, there’s at least one pedestrian or bicycle in the scene.",
        "No, we don’t see any pedestrians or bicycles around.",
        "Yep, either a pedestrian or a bike is present here.",
        "Nope, the frame doesn’t contain any people on foot or bicycles.",
        "We’ve got a pedestrian or a cyclist showing up in the current view."
    ],
    "Q8": [
        "Yes, there’s at least one object within 15 meters of us.",
        "No, everything we see is farther than 15 meters away.",
        "Something is indeed closer than 15 meters.",
        "All detected objects are beyond the 15-meter mark.",
        "There’s nothing within 15 meters of the ego vehicle."
    ],
    "Q9": [
        "Yes, the truck is in the mid-range zone, between 10 and 30 meters away.",
        "No, the truck is either too close or too far to be considered mid-range.",
        "The truck sits at a medium distance—right in the 10 to 30 meter band.",
        "It’s not in the mid-range; it’s either closer than 10 or farther than 30 meters.",
        "The truck falls squarely within the mid-range distance category."
    ],
    "Q10": [
        "Yes, both the [CLASS_A] and the [CLASS_B] are on the same side.",
        "No, the [CLASS_A] and the [CLASS_B] are on different sides.",
        "The [CLASS_A] and the [CLASS_B] are on the same side of the ego vehicle.",
        "The two regions are on opposite sides of the ego vehicle.",
        "These two regions are laterally consistent relative to ego."
    ],
    "Q11": [
        "The [CLASS] is riskier because it is much closer—only [DIST] meters away.",
        "Higher collision risk goes to the [CLASS]; it is just [DIST] meters away.",
        "The closest object, [CLASS], poses the greatest threat since it is only [DIST] meters from us.",
        "The main concern is the [CLASS], which is extremely close at [DIST] meters.",
        "Most hazardous is the [CLASS], sitting just [DIST] meters ahead with little room to maneuver."
    ],
    "Q12": [
        "The overall risk level of this scene is [RISK_LEVEL].",
        "This situation carries a [RISK_LEVEL] level of risk.",
        "We’re looking at a [RISK_LEVEL]-risk scenario right now.",
        "The driving context here is classified as [RISK_LEVEL] risk.",
        "From a safety standpoint, the risk in this frame is [RISK_LEVEL]."
    ],
    "Q13": [
        "Yes, this scene is taking place at an intersection.",
        "No, we’re not at an intersection right now.",
        "We are currently at an intersection.",
        "This isn’t an intersection—it’s a straight stretch of road.",
        "The layout clearly shows an intersection ahead."
    ],
    # Q14: 直接使用原始描述文本，不使用模板
    "Q15": [
        "Based on the current road and nearby objects, the ego vehicle is expected to follow this path: [TRAJ].",
        "Taking into account the scene context, the predicted trajectory is [TRAJ].",
        "The most likely future path for the ego, given what’s around, is [TRAJ].",
        "Considering the road geometry and traffic, we forecast the ego’s route as [TRAJ].",
        "The ego’s anticipated motion, shaped by the environment, looks like [TRAJ]."
    ],
    "Q16": [
        "If we project forward based on where the ego has been, the path comes out to [TRAJ].",
        "Extrapolating from the historical motion, the ego should end up following [TRAJ].",
        "Given how the vehicle has been moving, the natural continuation is [TRAJ].",
        "The trajectory inferred purely from past poses is [TRAJ].",
        "Rolling out the motion history gives us a future path of [TRAJ]."
    ],
    "Q17": [
        "In one second, the ego vehicle is expected to be at [COORDS].",
        "One second from now, the car should be located at [COORDS].",
        "We predict that after one second, the ego will reach [COORDS].",
        "The position of the ego vehicle one second ahead is estimated to be [COORDS].",
        "Looking one second into the future, the ego will be at [COORDS]."
    ],
    "Q18": [
        "In two seconds, the ego vehicle should be at [COORDS].",
        "Two seconds from now, we expect the car to be at [COORDS].",
        "After two seconds of travel, the ego’s position will be [COORDS].",
        "The predicted location of the ego at the two-second mark is [COORDS].",
        "Two seconds ahead, the vehicle is forecasted to be at [COORDS]."
    ],
    "Q19": [
        "In three seconds, the ego vehicle will likely be at [COORDS].",
        "Three seconds from now, the car is projected to reach [COORDS].",
        "After three seconds, the ego’s position is expected to be [COORDS].",
        "The three-second-ahead estimate for the ego’s location is [COORDS].",
        "Looking three seconds into the future, the ego should be at [COORDS]."
    ]
}

# 工具函数 
def map_risk_level(risk_str):
    level = int(risk_str)
    if level <= 3:
        return "low"
    elif level <= 6:
        return "medium"
    else:
        return "high"

def azimuth_to_natural_loc(azimuth_deg):
    if -10 <= azimuth_deg <= 10:
        return "ahead"
    elif 10 < azimuth_deg <= 45:
        return "right-front"
    elif 45 < azimuth_deg <= 90:
        return "right"
    elif 90 < azimuth_deg <= 135:
        return "right-rear"
    elif -45 <= azimuth_deg < -10:
        return "left-front"
    elif -90 <= azimuth_deg < -45:
        return "left"
    elif -135 <= azimuth_deg < -90:
        return "left-rear"
    else:
        return "behind"

def is_scene_desc_frame(image_name):
    frame_num = int(image_name.split('_')[-1].split('.')[0])
    return (frame_num % 10) == 3

def load_all_scene_descriptions(scene_id):
    desc_map = {}
    scene_desc_dir = os.path.join(INPUT_SCENE_DESC_ROOT, scene_id)
    if not os.path.exists(scene_desc_dir):
        return desc_map
    for json_file in os.listdir(scene_desc_dir):
        if not json_file.endswith(".json"):
            continue
        video_name = json_file[:-5]
        path = os.path.join(scene_desc_dir, json_file)
        try:
            with open(path, 'r') as f:
                data = json.load(f)
                for item in data:
                    img_name = item.get("image_name")
                    if img_name:
                        desc_map[img_name] = item
        except:
            continue
    return desc_map

def fill_template(template, **kwargs):
    for k, v in kwargs.items():
        template = template.replace(f"[{k.upper()}]", str(v))
    return template

def generate_scene_only_questions(image_name, scene_desc, batch_data, scale_valid):
    vqa_items = []
    risk_mapped = map_risk_level(scene_desc.get("risk_level", "0"))
    vqa_items.append({
        "question_type": "Q12",
        "answer": fill_template(random.choice(ANSWER_TEMPLATES["Q12"]), RISK_LEVEL=risk_mapped),
        "question_variants": random.sample(VQA_TEMPLATES["Q12"], 5)
    })
    desc_text = scene_desc.get("scene_description", "").lower()
    is_intersection = "intersection" in desc_text and "not an intersection" not in desc_text
    answer = "Yes, this is an intersection." if is_intersection else "No, it’s not an intersection."
    vqa_items.append({
        "question_type": "Q13",
        "answer": answer,
        "question_variants": random.sample(VQA_TEMPLATES["Q13"], 5)
    })
    desc_text = scene_desc.get("scene_description", "")
    risk_str = scene_desc.get("risk_level", "0")
    mapped_risk = map_risk_level(risk_str)
    new_desc = desc_text.replace(f"risk level score is {risk_str}", f"risk level is {mapped_risk}")
    vqa_items.append({
        "question_type": "Q14",
        "answer": new_desc,
        "question_variants": random.sample(VQA_TEMPLATES["Q14"], 5)
    })
    if scale_valid and is_scene_desc_frame(image_name):
        future_traj = batch_data.get("future_traj", [])
        if len(future_traj) >= 7:
            traj_6pts = str(future_traj[1:7])
            coord_1s = str(future_traj[2])
            coord_2s = str(future_traj[4])
            coord_3s = str(future_traj[6])
            vqa_items.append({
                "question_type": "Q15",
                "answer": fill_template(random.choice(ANSWER_TEMPLATES["Q15"]), TRAJ=traj_6pts),
                "question_variants": random.sample(VQA_TEMPLATES["Q15"], 5)
            })
            history_traj_str = str(batch_data.get("history_traj", []))
            questions_q16 = [
                q.replace("[HISTORY_TRAJ]", history_traj_str)
                for q in random.sample(VQA_TEMPLATES["Q16"], 5)
            ]
            vqa_items.append({
                "question_type": "Q16",
                "answer": fill_template(random.choice(ANSWER_TEMPLATES["Q16"]), TRAJ=traj_6pts),
                "question_variants": questions_q16
            })
            vqa_items.append({
                "question_type": "Q17",
                "answer": fill_template(random.choice(ANSWER_TEMPLATES["Q17"]), COORDS=coord_1s),
                "question_variants": random.sample(VQA_TEMPLATES["Q17"], 5)
            })
            vqa_items.append({
                "question_type": "Q18",
                "answer": fill_template(random.choice(ANSWER_TEMPLATES["Q18"]), COORDS=coord_2s),
                "question_variants": random.sample(VQA_TEMPLATES["Q18"], 5)
            })
            vqa_items.append({
                "question_type": "Q19",
                "answer": fill_template(random.choice(ANSWER_TEMPLATES["Q19"]), COORDS=coord_3s),
                "question_variants": random.sample(VQA_TEMPLATES["Q19"], 5)
            })
    return vqa_items
# VQA 生成函数
def generate_vqa_for_video(scene_id, video_name, scene_desc_map, batch_data_list):
    vqa_dict = {}
    for batch_data in batch_data_list:
        final_s = batch_data.get("final_s", 1.0)
        if abs(final_s - 1.0) < 1e-3:
            continue
        if final_s > 100:
            continue

        scale_valid = True

        for frame in batch_data.get("frames", []):
            image_name = frame.get("image_name")
            targets = frame.get("targets", [])

            if image_name not in vqa_dict:
                vqa_dict[image_name] = []

            if targets:
                frame_vqa = generate_questions_for_frame(
                    image_name=image_name,
                    targets=targets,
                    scene_desc=None,
                    is_sc_desc_frame=False,
                    batch_data=batch_data,
                    scale_valid=scale_valid
                )
                vqa_dict[image_name].extend(frame_vqa)

    return vqa_dict


def generate_questions_for_frame(image_name, targets, scene_desc, is_sc_desc_frame, batch_data, scale_valid):
    vqa_items = []

    # 只保留 Q1 / Q6 / Q10 / Q11

    if not scale_valid:
        return vqa_items

    valid_targets = [t for t in targets if t.get("distance_to_ego_m", 0) <= 50.0]
    if not valid_targets:
        return vqa_items

    #  Q1
    for t in valid_targets:
        rid = ref(t)
        dist = t.get("distance_to_ego_m", 0.0)
        az = t.get("azimuth_angle_deg", 0.0)

        template = random.choice(VQA_TEMPLATES["Q1"])
        ans_template = random.choice(ANSWER_TEMPLATES["Q1"])

        question = template.replace("[CLASS]", rid)
        answer = ans_template.replace("[CLASS]", rid) \
                     .replace("[DIST]", f"{dist:.2f}") \
                     .replace("[AZIMUTH]", f"{az:.2f}")

        vqa_items.append({
            "question_type": "Q1",
            "answer": answer,
            "question_variants": [question]
        })

    #  Q6 
    for i, t in enumerate(valid_targets):
        others = [x for j, x in enumerate(valid_targets) if j != i]
        if not others:
            continue

        nearest_other = min(
            others,
            key=lambda x: abs(
                x.get("distance_to_ego_m", 0) - t.get("distance_to_ego_m", 0)
            )
        )

        da = t.get("distance_to_ego_m", 0.0)
        db = nearest_other.get("distance_to_ego_m", 0.0)

        diff = abs(da - db)
        if diff < 0.1:
            continue

        ra = ref(t)
        rb = ref(nearest_other)

        closer = "closer" if da < db else "farther"

        template = random.choice(VQA_TEMPLATES["Q6"])
        ans_template = random.choice(ANSWER_TEMPLATES["Q6"])

        question = template.replace("[CLASS_A]", ra).replace("[CLASS_B]", rb)

        answer = ans_template.replace("[CLASS_A]", ra).replace("[CLASS_B]", rb) \
                             .replace("[DIFF]", f"{diff:.2f}") \
                             .replace("[CLOSER_OR_FARTHER]", closer) \
                             .replace("[CLOSER_OR_FARTHER_REVERSE]",
                                      "farther" if closer == "closer" else "closer")

        vqa_items.append({
            "question_type": "Q6",
            "answer": answer,
            "question_variants": [question]
        })

    # Q10 
    if len(valid_targets) >= 2:
        a = valid_targets[0]
        b = valid_targets[1]

        ra = ref(a)
        rb = ref(b)

        side_a = azimuth_to_natural_loc(a.get("azimuth_angle_deg", 0))
        side_b = azimuth_to_natural_loc(b.get("azimuth_angle_deg", 0))

        template = random.choice(VQA_TEMPLATES["Q10"])
        question = template.replace("[CLASS_A]", ra).replace("[CLASS_B]", rb)

        if side_a == side_b:
            answer = f"Yes, {ra} and {rb} are on the same side."
        else:
            answer = f"No, {ra} and {rb} are on different sides."

        vqa_items.append({
            "question_type": "Q10",
            "answer": answer,
            "question_variants": [question]
        })

    # Q11 
    def risk_score(t):
        d = t.get("distance_to_ego_m", float('inf'))
        label = t.get("label", "")
        w = 1.5 if label == "truck" else 1.0
        return d / w

    sorted_targets = sorted(valid_targets, key=risk_score)
    high_risk = sorted_targets[0]

    r = ref(high_risk)
    dist = high_risk.get("distance_to_ego_m", 0.0)

    template = random.choice(VQA_TEMPLATES["Q11"])
    ans_template = random.choice(ANSWER_TEMPLATES["Q11"])

    question = template

    answer = ans_template.replace("[CLASS]", r) \
                         .replace("[DIST]", f"{dist:.2f}")

    vqa_items.append({
        "question_type": "Q11",
        "answer": answer,
        "question_variants": [question]
    })
    return vqa_items 


def main():
    os.makedirs(OUTPUT_CHAT_ROOT, exist_ok=True)

    for scene_id in SCENE_IDS:
        print(f"\n=== Processing {scene_id} ===")
        output_scene_dir = os.path.join(OUTPUT_CHAT_ROOT, scene_id)
        os.makedirs(output_scene_dir, exist_ok=True)

        scene_desc_map = load_all_scene_descriptions(scene_id)
        video_dir = os.path.join(INPUT_YIPI_ROOT, scene_id)
        if not os.path.exists(video_dir):
            continue

        video_names = [d for d in os.listdir(video_dir) if os.path.isdir(os.path.join(video_dir, d))]
        for video_name in sorted(video_names):

            batch_dir = os.path.join(video_dir, video_name)
            batch_files = sorted(glob.glob(os.path.join(batch_dir, "batch_*.json")))

            batch_data_list = []
            for batch_file in batch_files:
                try:
                    with open(batch_file, 'r') as f:
                        batch_data = json.load(f)
                    batch_data_list.append(batch_data)
                except:
                    continue

            vqa_dict = generate_vqa_for_video(scene_id, video_name, scene_desc_map, batch_data_list)

            chat_list = []
            for image_name, questions in vqa_dict.items():

                abs_image_path = os.path.join(DATASET_ROOT, scene_id, video_name, image_name)

                for q_item in questions:
                    q = random.choice(q_item["question_variants"])
                    a = q_item["answer"]

                    chat_list.append({
                        "messages": [
                            {"role": "user", "content": f"<image> {q}"},
                            {"role": "assistant", "content": a}
                        ],
                        "images": [abs_image_path]
                    })

            output_file = os.path.join(output_scene_dir, f"{video_name}.json")
            with open(output_file, 'w') as f:
                json.dump(chat_list, f, indent=2, ensure_ascii=False)

            print(f"Saved {len(chat_list)}")


if __name__ == "__main__":
    main()