
import os
import json
import time
import re
from tqdm import tqdm
from vllm import LLM, EngineArgs, SamplingParams
from transformers import AutoProcessor
from dataclasses import asdict
from qwen_vl_utils import process_vision_info

if __name__ == '__main__':
    print("开始运行 Qwen2-VL 场景描述生成脚本")

    # 路径
    dataset_dir = "images path"
    model_path = "Qwen2-VL-72B-Instruct path"
    output_dir = "your output path"

    os.makedirs(output_dir, exist_ok=True)

    # 提示词模板
    prompt_template = (
        "You are a professional text generator. "
        "Please describe the weather from [sunny, cloudy, rainy, foggy, snowy], time from [daytime, night], "
        "road type from [urban, suburb, rural, highway], and indicate whether in an intersection, how many lanes of the image (including 0). "
        "Also, assess the risk level of this scenario on a scale of 1 to 10, where 1 is safest and 10 is most dangerous. "
        "Consider the apparent proximity and spatial configuration of traffic participants, "
        "obstacles and road occupancy, potential path conflicts suggested by the visible scene, "
        "road and intersection complexity, visibility, and environmental conditions. "
        'Output strictly like: '
        '"The weather is cloudy, and it is daytime. The road type is urban and the road has four lanes. It is an intersection, and the risk level score is 6."'
    )

    # 模型参数
    BATCH_SIZE = 30
    TENSOR_PARALLEL_SIZE = 4
    IMAGE_RESIZE = (448, 448)

    # 初始化模型
    print("使用 vLLM 加载模型...")
    llm = LLM(**asdict(EngineArgs(
        model=model_path,
        tensor_parallel_size=TENSOR_PARALLEL_SIZE,
        max_model_len=32768,
        max_num_seqs=32,
        gpu_memory_utilization=0.9,
        limit_mm_per_prompt={"image": 1},
        allowed_local_media_path=dataset_dir
    )))

    sampling_params = SamplingParams(temperature=0.0, max_tokens=256)

    # 初始化 processor
    processor = AutoProcessor.from_pretrained(model_path, size={"height": IMAGE_RESIZE[0], "width": IMAGE_RESIZE[1]})

    print(f"正在扫描目录: {dataset_dir}")

    TARGET_CATEGORIES = {
        "xxx"#需要处理的文件夹名称
    }


    for category in sorted(os.listdir(dataset_dir)):
        category_path = os.path.join(dataset_dir, category)
        if not os.path.isdir(category_path):
            print(f"跳过非文件夹项: {category}")
            continue

        if category not in TARGET_CATEGORIES:
            print(f"跳过非目标文件夹: {category}")
            continue

        print(f"\n分类目录: {category}")


        for video in sorted(os.listdir(category_path)):
            video_path = os.path.join(category_path, video)
            if not os.path.isdir(video_path):
                print(f"跳过非文件夹项: {video}")
                continue

            print(f"检测到视频文件夹: {video}")


            jpg_files = [f for f in os.listdir(video_path) if f.lower().endswith(".jpg")]
            jpg_files.sort()  

            if len(jpg_files) < 10:
                print(f"跳过视频: {video}，图像数量不足 10（当前: {len(jpg_files)}）")
                continue

            print(f"处理视频: {video}，图像数量: {len(jpg_files)}")

            output_file = os.path.join(output_dir, category, f"{video}.json")
            os.makedirs(os.path.dirname(output_file), exist_ok=True)

            print(f"输出文件: {output_file}")

            existing_results = []
            if os.path.exists(output_file):
                try:
                    with open(output_file, 'r', encoding='utf-8') as f:
                        existing_results = json.load(f)
                        print(f"已存在的结果: {output_file}, 处理进度: {len(existing_results)}")
                except json.JSONDecodeError:
                    print(f"警告: {output_file} 文件损坏，将重新生成")
                    existing_results = []
            else:
                print(f"新建结果文件: {output_file}")

            processed_count = len(existing_results)
            total_groups = len(jpg_files) // 10
            remaining_groups = total_groups - processed_count

            progress_bar = tqdm(
                total=total_groups,
                initial=processed_count,
                desc=f"处理 {video}",
                unit="样本"
            )

            batch_results = []

            try:
                for i in range(processed_count, total_groups):
                    group = jpg_files[i * 10:(i + 1) * 10]
                    if len(group) < 4:
                        print(f"组内不足4张图，跳过该组")
                        continue  

                    img_name = group[3]
                    full_path = os.path.join(video_path, img_name)

                    messages = [{
                        "role": "user",
                        "content": [
                            {"type": "image", "image": full_path},
                            {"type": "text", "text": prompt_template}
                        ]
                    }]

                    image_inputs, _ = process_vision_info(messages)
                    text = processor.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)

                    input_data = {
                        "prompt": text,
                        "multi_modal_data": {"image": image_inputs}
                    }

                    start_time = time.time()

                    outputs = llm.generate([input_data], sampling_params=sampling_params)
                    output_text = outputs[0].outputs[0].text.strip()

                    try:
                        model_output = output_text.split("assistant\n")[-1].strip()
                    except IndexError:
                        model_output = output_text.strip()

                    risk_score_match = re.search(r"risk level score is (\d+)", model_output, re.IGNORECASE)
                    risk_level = risk_score_match.group(1) if risk_score_match else "1"

                    result = {
                        "id": i + 1,
                        "video_name": video,
                        "image_name": img_name,
                        "risk_level": risk_level,
                        "scene_description": model_output
                    }
                    batch_results.append(result)

                    if len(batch_results) >= 10 or i == total_groups - 1:
                        try:
                            with open(output_file, 'r', encoding='utf-8') as f:
                                all_results = json.load(f)
                        except (FileNotFoundError, json.JSONDecodeError):
                            all_results = []

                        all_results.extend(batch_results)

                        with open(output_file, 'w', encoding='utf-8') as f:
                            json.dump(all_results, f, indent=4, ensure_ascii=False)
                            f.flush()
                            os.fsync(f.fileno()) 

                        duration = time.time() - start_time
                        print(f"[{i - len(batch_results) + 1}-{i + 1}] 批次处理耗时: {duration:.2f} 秒")

                        batch_results.clear()

                    progress_bar.update(1)

                progress_bar.close()
                print(f"视频 {video} 处理完成")

            except Exception as e:
                progress_bar.close()
                print(f"推理异常中断: {e}")
                print(f"已保存当前批次结果，请重新运行以继续处理 {video}")

    print("所有指定视频处理完毕！")