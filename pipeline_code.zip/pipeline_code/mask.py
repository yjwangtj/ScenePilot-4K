import os
import json
import cv2
import numpy as np
import torch
import shutil

from segment_anything import sam_model_registry, SamPredictor

# 路径
dataset_roots = [
    ("your images_path", "your YOLO_output_path"),
]

save_root = "your save_path"
os.makedirs(save_root, exist_ok=True)


# SAM
sam_ckpt = "your SAM.pth"
model_type = "your SAM's type"
device = "cuda" if torch.cuda.is_available() else "cpu"

sam = sam_model_registry[model_type](checkpoint=sam_ckpt)
sam.to(device=device)
predictor = SamPredictor(sam)

IMG_W = 852
IMG_H = 480

colors = [
    (255, 99, 71),
    (135, 206, 235),
    (60, 179, 113),
    (255, 215, 0),
    (138, 43, 226),
    (255, 140, 0),
    (0, 191, 255),
    (50, 205, 50),
    (255, 105, 180),
    (0, 255, 255),
]


for image_root, json_root in dataset_roots:

    dataset_name = os.path.basename(image_root)

    for seq in sorted(os.listdir(image_root)):

        image_dir = os.path.join(image_root, seq)
        json_dir = os.path.join(json_root, seq)

        if not os.path.isdir(image_dir):
            continue

        json_path = os.path.join(json_dir, "final_output.json")

        image_objects = {}

        if os.path.exists(json_path):
            with open(json_path, "r") as f:
                data = json.load(f)

            for item in data:
                image_objects[item["image_name"]] = item["key_objects"]

        save_dir = os.path.join(save_root, dataset_name, seq)

        if os.path.exists(save_dir) and len(os.listdir(save_dir)) > 0:
            print("skip seq:", save_dir)
            continue
        os.makedirs(save_dir, exist_ok=True)

        for image_name in sorted(os.listdir(image_dir)):

            image_path = os.path.join(image_dir, image_name)
            save_path = os.path.join(save_dir, image_name)

            img = cv2.imread(image_path)

            if img is None:
                print("missing:", image_path)
                continue

            if image_name not in image_objects or len(image_objects[image_name]) == 0:
                shutil.copy(image_path, save_path)
                continue

            image_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

            predictor.set_image(image_rgb)

            vis = image_rgb.copy()

            for obj in image_objects[image_name]:

                object_id = int(obj["object_id"])

                cx, cy, w, h = obj["bbox_2d"]

                cx *= IMG_W
                cy *= IMG_H
                w *= IMG_W
                h *= IMG_H

                x1 = int(cx - w/2)
                y1 = int(cy - h/2)
                x2 = int(cx + w/2)
                y2 = int(cy + h/2)

                box = np.array([x1, y1, x2, y2])

                masks, scores, _ = predictor.predict(
                    box=box,
                    multimask_output=True
                )

                best_idx = np.argmax(scores)
                best_mask = masks[best_idx]

                color = np.array(colors[object_id % len(colors)], dtype=np.uint8)
                alpha = 0.45

                vis[best_mask] = (
                    vis[best_mask].astype(np.float32) * (1 - alpha)
                    + color.astype(np.float32) * alpha
                ).astype(np.uint8)

                mask_uint8 = (best_mask.astype(np.uint8) * 255)

                contours,_ = cv2.findContours(
                    mask_uint8,
                    cv2.RETR_EXTERNAL,
                    cv2.CHAIN_APPROX_SIMPLE
                )

                contour_alpha = 0.6
                overlay = vis.copy()

                cv2.drawContours(
                        overlay,
                        contours,
                        -1,
                        tuple(int(c) for c in color.tolist()),
                        2
                )

                vis = cv2.addWeighted(
                        overlay,
                        contour_alpha,
                        vis,
                        1 - contour_alpha,
                        0
                )

                # 写 Region ID
                ys, xs = np.where(best_mask)

                if len(xs) > 0:
                    cx = int(xs.mean())
                    cy = int(ys.mean())

                    region_id = object_id
                    text = str(region_id)

                    area = int(best_mask.sum())

                    if area > 120000:
                        font_scale = 3.0
                        thick_white = 10
                        thick_black = 20
                    elif area > 40000:
                        font_scale = 2.4
                        thick_white = 8
                        thick_black = 16
                    elif area > 12000:
                        font_scale = 2.0
                        thick_white = 8
                        thick_black = 14
                    else:
                        font_scale = 1.6
                        thick_white = 6
                        thick_black = 12

                    font_scale *= 0.3
                    thick_white = max(1, int(thick_white * 0.3))
                    thick_black = max(1, int(thick_black * 0.3))

                    (tw, th), _ = cv2.getTextSize(
                        text,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        font_scale,
                        thick_white,
                    )

                    org = (int(cx - tw / 2), int(cy + th / 2))

                    cv2.putText(
                        vis,
                        text,
                        org,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        font_scale,
                        (0, 0, 0),
                        thick_black,
                        cv2.LINE_AA,
                    )

                    cv2.putText(
                        vis,
                        text,
                        org,
                        cv2.FONT_HERSHEY_SIMPLEX,
                        font_scale,
                        (255, 255, 255),
                        thick_white,
                        cv2.LINE_AA,
                    )

            vis_bgr = cv2.cvtColor(vis, cv2.COLOR_RGB2BGR)
            cv2.imwrite(save_path, vis_bgr)

            print("saved:", save_path)