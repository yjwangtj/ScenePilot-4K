import json
import math
import copy
from pathlib import Path
from typing import Any, Dict, List

# =========================
# 路径配置
# =========================
SRC_ROOTS = [
    Path("original VGGT path"),
]

DST_ROOT = Path("save path")
SUMMARY_PATH = Path("summary.json save_path")
REMOVED_PATHS_JSON = Path("removed_src_json_paths.json")


# 阈值配置
EPS_EQUAL = 1e-6              
MAX_HEADING_CHANGE_RAD = 1.2  # x-z 平面相邻线段航向变化阈值，约 68.8°
MIN_DX_LATERAL = 0.25
MAX_DY_LATERAL = 0.08
MAX_DZ_LATERAL = 0.08
LATERAL_RATIO = 3.0
MIN_CONSECUTIVE_LATERAL = 2

DT = 0.5  

LOW_MOTION_MIN_MEAN_SPEED_XZ = 1.0
LOW_MOTION_MIN_MAX_SPEED_XZ = 1.5
LOW_MOTION_MIN_PATH_LEN_XZ = 1.0
LOW_MOTION_MIN_HIT_COUNT = 3

STRAIGHT_X_SPAN_MAX = 0.4         
STRAIGHT_SUM_ABS_DX_MAX = 0.8      
STRAIGHT_HEADING_VAR_MAX = 0.15   
MIN_SEG_LEN_FOR_HEADING = 0.15    
MIN_PATH_LEN_FOR_CURVATURE = 2.0  

MIN_SPEED_FOR_ACCEL_CHECK = 1.0
MAX_ACCEL_DIFF_NORM = 8.0
MIN_CONSECUTIVE_ACCEL_DIFF = 2

def load_json(path: Path) -> Any:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

def collect_json_files_from_multiple_roots(src_roots: List[Path]) -> List[tuple]:

    collected = []
    used_top_dirs = set()

    for src_root in src_roots:
        if not src_root.exists():
            print(f"[WARN] 源目录不存在，跳过: {src_root}")
            continue

        top_dirs = sorted([p for p in src_root.iterdir() if p.is_dir()])

        for top_dir in top_dirs:
            top_name = top_dir.name
            if top_name in used_top_dirs:
                print(f"[SKIP] 重复子文件夹，按优先级跳过: {top_dir}")
                continue

            used_top_dirs.add(top_name)

            for json_path in sorted(top_dir.rglob("*.json")):
                collected.append((src_root, json_path))

    return collected

def vec_sub(a: List[float], b: List[float]) -> List[float]:
    return [float(a[i]) - float(b[i]) for i in range(3)]

def point_dist_xz(a: List[float], b: List[float]) -> float:
    return math.sqrt(
        (float(a[0]) - float(b[0])) ** 2 +
        (float(a[2]) - float(b[2])) ** 2
    )

def vec_norm(v: List[float]) -> float:
    return math.sqrt(sum(float(x) * float(x) for x in v))

def vec_norm_xz(v: List[float]) -> float:
    return math.sqrt(float(v[0]) * float(v[0]) + float(v[2]) * float(v[2]))

def angle_wrap_pi(angle: float) -> float:
    while angle > math.pi:
        angle -= 2 * math.pi
    while angle < -math.pi:
        angle += 2 * math.pi
    return angle


def get_all_points(history_traj: List[List[float]], future_traj: List[List[float]]) -> List[List[float]]:
    """ history 和 future 拼起来
    """
    hist = history_traj if isinstance(history_traj, list) else []
    fut = future_traj if isinstance(future_traj, list) else []
    return hist + fut

def is_straight_motion_prior(points: List[List[float]]) -> bool:
    if len(points) < 3:
        return True

    xs = [float(p[0]) for p in points]
    x_span = max(xs) - min(xs)

    sum_abs_dx = 0.0
    path_len_xz = 0.0
    headings = []

    for i in range(len(points) - 1):
        dx = float(points[i + 1][0]) - float(points[i][0])
        dz = float(points[i + 1][2]) - float(points[i][2])
        seg_len = math.sqrt(dx * dx + dz * dz)

        sum_abs_dx += abs(dx)
        path_len_xz += seg_len

        if seg_len >= MIN_SEG_LEN_FOR_HEADING:
            headings.append(math.atan2(dx, dz))

    if path_len_xz < MIN_PATH_LEN_FOR_CURVATURE:
        return True

    if len(headings) >= 2:
        heading_diffs = [
            abs(angle_wrap_pi(headings[i + 1] - headings[i]))
            for i in range(len(headings) - 1)
        ]
        max_heading_diff = max(heading_diffs) if heading_diffs else 0.0
    else:
        max_heading_diff = 0.0

    return (
        x_span <= STRAIGHT_X_SPAN_MAX and
        sum_abs_dx <= STRAIGHT_SUM_ABS_DX_MAX and
        max_heading_diff <= STRAIGHT_HEADING_VAR_MAX
    )

#用三个点直接构造加速度
def compute_three_point_accelerations(
    points: List[List[float]],
    dt: float = DT,
) -> List[List[float]]:
    accs = []
    if len(points) < 3:
        return accs

    for i in range(len(points) - 2):
        p0, p1, p2 = points[i], points[i + 1], points[i + 2]
        ax = (float(p2[0]) - 2.0 * float(p1[0]) + float(p0[0])) / (dt * dt)
        ay = (float(p2[1]) - 2.0 * float(p1[1]) + float(p0[1])) / (dt * dt)
        az = (float(p2[2]) - 2.0 * float(p1[2]) + float(p0[2])) / (dt * dt)
        accs.append([ax, ay, az])

    return accs

#check low motion
def check_low_motion(
    history_traj: List[List[float]],
    future_traj: List[List[float]],
    dt: float = DT,
    min_mean_speed_xz: float = LOW_MOTION_MIN_MEAN_SPEED_XZ,
    min_max_speed_xz: float = LOW_MOTION_MIN_MAX_SPEED_XZ,
    min_path_len_xz: float = LOW_MOTION_MIN_PATH_LEN_XZ,
    min_hit_count: int = LOW_MOTION_MIN_HIT_COUNT,
) -> bool:
    points = []
    if isinstance(history_traj, list):
        points.extend(history_traj)
    if isinstance(future_traj, list):
        points.extend(future_traj)

    if len(points) < 2:
        return False

    speeds_xz = []
    path_len_xz = 0.0

    for i in range(len(points) - 1):
        dp = vec_sub(points[i + 1], points[i])
        speed_xz = vec_norm_xz(dp) / dt
        speeds_xz.append(speed_xz)
        path_len_xz += point_dist_xz(points[i], points[i + 1])

    mean_speed_xz = sum(speeds_xz) / len(speeds_xz)
    max_speed_xz = max(speeds_xz)

    hit_count = 0
    if mean_speed_xz < min_mean_speed_xz:
        hit_count += 1
    if max_speed_xz < min_max_speed_xz:
        hit_count += 1
    if path_len_xz < min_path_len_xz:
        hit_count += 1

    return hit_count >= min_hit_count

#check lateral shift
def check_lateral_shift(
    points: List[List[float]],
    min_dx: float = MIN_DX_LATERAL,
    max_dy: float = MAX_DY_LATERAL,
    max_dz: float = MAX_DZ_LATERAL,
    lateral_ratio: float = LATERAL_RATIO,
    min_consecutive_segments: int = MIN_CONSECUTIVE_LATERAL,
) -> bool:

    if len(points) < 2:
        return False

    consecutive = 0

    for i in range(len(points) - 1):
        p1, p2 = points[i], points[i + 1]

        dx = abs(float(p2[0]) - float(p1[0]))
        dy = abs(float(p2[1]) - float(p1[1]))
        dz = abs(float(p2[2]) - float(p1[2]))

        is_lateral = (
            dx >= min_dx and
            dy <= max_dy and
            dz <= max_dz and
            dx >= lateral_ratio * max(dy, EPS_EQUAL) and
            dx >= lateral_ratio * max(dz, EPS_EQUAL)
        )

        if is_lateral:
            consecutive += 1
            if consecutive >= min_consecutive_segments:
                return True
        else:
            consecutive = 0

    return False

#check curvature
def check_curvature(
    points: List[List[float]],
    max_heading_change_rad: float = MAX_HEADING_CHANGE_RAD,
    min_seg_len_for_heading: float = MIN_SEG_LEN_FOR_HEADING,
    straight_dz_min: float = 0.3,
    straight_ratio: float = 0.2,
) -> bool:
    if len(points) < 3:
        return False

    valid_headings = []

    for i in range(len(points) - 1):
        dx = float(points[i + 1][0]) - float(points[i][0])
        dz = float(points[i + 1][2]) - float(points[i][2])
        seg_len = math.sqrt(dx * dx + dz * dz)

        if seg_len < min_seg_len_for_heading:
            continue

        # 近似直线段不参与曲率计算
        if abs(dz) >= straight_dz_min and abs(dx) <= straight_ratio * abs(dz):
            continue

        valid_headings.append(math.atan2(dx, dz))

    if len(valid_headings) < 2:
        return False

    for i in range(len(valid_headings) - 1):
        dtheta = abs(angle_wrap_pi(valid_headings[i + 1] - valid_headings[i]))
        if dtheta > max_heading_change_rad:
            return True

    return False

#check acceleration
def check_acceleration(
    points: List[List[float]],
    dt: float = DT,
    min_speed_for_check: float = MIN_SPEED_FOR_ACCEL_CHECK,
    max_accel_diff_norm: float = MAX_ACCEL_DIFF_NORM,
    min_consecutive_accel_diff: int = MIN_CONSECUTIVE_ACCEL_DIFF,
) -> bool:
    if len(points) < 4:
        return False

    stats = get_motion_stats(points, dt=dt)
    if stats["mean_speed_xz"] < min_speed_for_check:
        return False

    accs = compute_three_point_accelerations(points, dt=dt)
    if len(accs) < 2:
        return False

    consecutive = 0
    for i in range(len(accs) - 1):
        da = vec_sub(accs[i + 1], accs[i])
        if vec_norm_xz(da) > max_accel_diff_norm:
            consecutive += 1
            if consecutive >= min_consecutive_accel_diff:
                return True
        else:
            consecutive = 0

    return False

def get_motion_stats(points: List[List[float]], dt: float = DT) -> Dict[str, float]:
    if len(points) < 2:
        return {
            "path_len_xz": 0.0,
            "mean_speed_xz": 0.0,
            "max_speed_xz": 0.0,
        }

    speeds_xz = []
    path_len_xz = 0.0
    for i in range(len(points) - 1):
        dp = vec_sub(points[i + 1], points[i])
        speed_xz = vec_norm_xz(dp) / dt
        speeds_xz.append(speed_xz)
        path_len_xz += point_dist_xz(points[i], points[i + 1])

    return {
        "path_len_xz": path_len_xz,
        "mean_speed_xz": sum(speeds_xz) / len(speeds_xz),
        "max_speed_xz": max(speeds_xz),
    }


def analyze_traj(history_traj: Any, future_traj: Any) -> Dict[str, bool]:
    if not isinstance(history_traj, list):
        history_traj = []
    if not isinstance(future_traj, list):
        future_traj = []

    points = get_all_points(history_traj, future_traj)
    stats = get_motion_stats(points, dt=DT)

    low_motion = check_low_motion(
        history_traj,
        future_traj,
        dt=DT,
        min_mean_speed_xz=LOW_MOTION_MIN_MEAN_SPEED_XZ,
        min_max_speed_xz=LOW_MOTION_MIN_MAX_SPEED_XZ,
        min_path_len_xz=LOW_MOTION_MIN_PATH_LEN_XZ,
        min_hit_count=LOW_MOTION_MIN_HIT_COUNT,
    )

    enough_motion_for_dynamic_checks = (
        stats["path_len_xz"] >= 2.0 and
        stats["mean_speed_xz"] >= 1.0
    )

    straight_prior = is_straight_motion_prior(points)

    reasons = {
        "low_motion": low_motion,
        "lateral_shift": check_lateral_shift(points),
        "curvature_unreasonable": (
            check_curvature(points)
            if (enough_motion_for_dynamic_checks and not straight_prior)
            else False
        ),
        "acceleration_unreasonable": (
            check_acceleration(points, dt=DT)
            if enough_motion_for_dynamic_checks
            else False
        ),
    }
    return reasons


def remove_traj_fields(sample: Dict[str, Any]) -> Dict[str, Any]:
    new_sample = copy.deepcopy(sample)
    new_sample.pop("history_traj", None)
    new_sample.pop("future_traj", None)
    return new_sample

def build_case_info(sample: Dict[str, Any], src_path: Path, reasons: Dict[str, bool]) -> Dict[str, Any]:
    return {
        "src_json_path": str(src_path),
        "video_name": sample.get("video_name"),
        "start_frame_name": sample.get("start_frame_name"),
        "reasons": [k for k, v in reasons.items() if v],
        "history_traj": sample.get("history_traj", []),
        "future_traj": sample.get("future_traj", []),
    }

def record_invalid_case(summary: Dict[str, Any], case_info: Dict[str, Any], reasons: Dict[str, bool]) -> None:
    for reason, hit in reasons.items():
        if hit:
            summary["reason_counts"][reason] += 1
            summary["details"][reason].append(case_info)

def process_one_record(sample: Dict[str, Any], src_path: Path, summary: Dict[str, Any]) -> Dict[str, Any]:
    summary["total_records"] += 1

    history_traj = sample.get("history_traj", [])
    future_traj = sample.get("future_traj", [])

    reasons = analyze_traj(history_traj, future_traj)
    is_bad = any(reasons.values())

    if is_bad:
        summary["invalid_records"] += 1

        src_path_str = str(src_path)
        if src_path_str not in summary["removed_src_json_paths"]:
            summary["removed_src_json_paths"].append(src_path_str)

        case_info = build_case_info(sample, src_path, reasons)
        record_invalid_case(summary, case_info, reasons)
        return remove_traj_fields(sample)

    summary["valid_records"] += 1
    return sample


def process_json_content(data: Any, src_path: Path, summary: Dict[str, Any]) -> Any:
    if isinstance(data, dict):
        return process_one_record(data, src_path, summary)

    if isinstance(data, list):
        out = []
        for item in data:
            if isinstance(item, dict):
                out.append(process_one_record(item, src_path, summary))
            else:
                out.append(item)
        return out

    return data


def save_compact_summary_json(path: Path, summary: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    meta = {
        "src_roots": summary["src_roots"],
        "dst_root": summary["dst_root"],
        "total_json_files": summary["total_json_files"],
        "total_records": summary["total_records"],
        "valid_records": summary["valid_records"],
        "invalid_records": summary["invalid_records"],
        "reason_counts": summary["reason_counts"],
        "thresholds": summary["thresholds"],
        "details": {}
    }

    for reason, cases in summary["details"].items():
        meta["details"][reason] = []
        for case in cases:
            meta["details"][reason].append({
                "src_json_path": case["src_json_path"],
                "video_name": case["video_name"],
                "start_frame_name": case["start_frame_name"],
                "reasons": case["reasons"],
                "history_traj": case["history_traj"],
                "future_traj": case["future_traj"],
            })

    with open(path, "w", encoding="utf-8") as f:
        json.dump(meta, f, ensure_ascii=False, indent=2)

def save_removed_src_json_paths(path: Path, summary: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

    data = {
        "dst_root": summary["dst_root"],
        "removed_src_json_path_count": len(summary["removed_src_json_paths"]),
        "removed_src_json_paths": sorted(summary["removed_src_json_paths"]),
    }

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
def main():
    json_file_entries = collect_json_files_from_multiple_roots(SRC_ROOTS)

    if not json_file_entries:
        raise FileNotFoundError("没有找到任何可处理的 JSON 文件")

    summary = {
        "src_roots": [str(p) for p in SRC_ROOTS],
        "dst_root": str(DST_ROOT),
        "total_json_files": 0,
        "total_records": 0,
        "valid_records": 0,
        "invalid_records": 0,
        "removed_src_json_paths": [],
        "reason_counts": {
            "low_motion": 0,
            "lateral_shift": 0,
            "curvature_unreasonable": 0,
            "acceleration_unreasonable": 0,
        },
        "thresholds": {
            "DT": DT,
            "EPS_EQUAL": EPS_EQUAL,
            "MAX_HEADING_CHANGE_RAD": MAX_HEADING_CHANGE_RAD,
            "MIN_DX_LATERAL": MIN_DX_LATERAL,
            "MAX_DY_LATERAL": MAX_DY_LATERAL,
            "MAX_DZ_LATERAL": MAX_DZ_LATERAL,
            "LATERAL_RATIO": LATERAL_RATIO,
            "MIN_CONSECUTIVE_LATERAL": MIN_CONSECUTIVE_LATERAL,
            "LOW_MOTION_MIN_MEAN_SPEED_XZ": LOW_MOTION_MIN_MEAN_SPEED_XZ,
            "LOW_MOTION_MIN_MAX_SPEED_XZ": LOW_MOTION_MIN_MAX_SPEED_XZ,
            "LOW_MOTION_MIN_PATH_LEN_XZ": LOW_MOTION_MIN_PATH_LEN_XZ,
            "LOW_MOTION_MIN_HIT_COUNT": LOW_MOTION_MIN_HIT_COUNT,
            "MAX_ACCEL_DIFF_NORM": MAX_ACCEL_DIFF_NORM,
            "MIN_CONSECUTIVE_ACCEL_DIFF": MIN_CONSECUTIVE_ACCEL_DIFF,
        },
        "details": {
            "low_motion": [],
            "lateral_shift": [],
            "curvature_unreasonable": [],
            "acceleration_unreasonable": [],
        }
    }

    for src_root, src_path in json_file_entries:
        rel_path = src_path.relative_to(src_root)
        dst_path = DST_ROOT / rel_path

        try:
            data = load_json(src_path)
            out_data = process_json_content(data, src_path, summary)
            save_json(dst_path, out_data)
            summary["total_json_files"] += 1
            print(f"[OK] {src_path} -> {dst_path}")
        except Exception as e:
            print(f"[ERROR] {src_path}: {e}")

    save_compact_summary_json(SUMMARY_PATH, summary)
    save_removed_src_json_paths(REMOVED_PATHS_JSON, summary)

    print("\n===== Done =====")
    print(f"Total json files: {summary['total_json_files']}")
    print(f"Total records   : {summary['total_records']}")
    print(f"Valid records   : {summary['valid_records']}")
    print(f"Invalid records : {summary['invalid_records']}")
    print(f"Removed src json paths: {len(summary['removed_src_json_paths'])}")
    print(f"Summary saved to: {SUMMARY_PATH}")
    print(f"Removed paths saved to: {REMOVED_PATHS_JSON}")


if __name__ == "__main__":
    main()