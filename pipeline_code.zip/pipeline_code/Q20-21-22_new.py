
import os
import json
import random
import glob

OUTPUT_ROOT = "your output path"

DATA_SOURCES = [
    {
        "root": "VGGT path",
        "scenes": [
            "xxx"#文件夹名称
        ]
    }
]

DATASET_ROOT = "your images path"

DISTANCE_ANSWERS = [
    "Their distance is [DIST] meters.",
    "The distance between them is [DIST] meters.",
    "They are [DIST] meters apart.",
    "The separation between them measures [DIST] meters.",
    "There is a [DIST]-meter gap between them."
]

ANGLE_DIFF_ANSWERS = [
    "Their azimuthal difference is [ANGLE_DIFF] degrees.",
    "The angular offset between them is [ANGLE_DIFF] degrees.",
    "They differ in azimuth by [ANGLE_DIFF] degrees.",
    "The bearing directions to them are [ANGLE_DIFF] degrees apart.",
    "Their azimuthal separation is [ANGLE_DIFF] degrees."
]

BEARING_ANSWERS = [
    "From the first to the second, the bearing is [BEARING] degrees ([DIRECTION]).",
    "The direction from the first to the second is [BEARING] degrees ([DIRECTION]).",
    "The absolute heading from the first toward the second is [BEARING] degrees ([DIRECTION]).",
    "Looking from the first, the second appears at [BEARING] degrees ([DIRECTION]).",
    "The bearing from the first object to the second is [BEARING] degrees ([DIRECTION])."
]

DIST_TEMPLATES = [
    "How far is the [REF_A] from the [REF_B]?",
    "What is the distance between the [REF_A] and the [REF_B]?",
    "Measure the separation between the [REF_A] and the [REF_B].",
    "Provide the distance in meters between the [REF_A] and the [REF_B].",
    "How many meters apart are the [REF_A] and the [REF_B]?",
]

ANGLE_TEMPLATES = [
    "What is the azimuthal difference between the [REF_A] and the [REF_B]?",
    "How many degrees apart are the [REF_A] and the [REF_B] in bearing?",
    "What is the angular offset of the [REF_B] relative to the [REF_A]?",
    "How much does the azimuth of the [REF_B] differ from that of the [REF_A]?",
]

BEARING_TEMPLATES = [
    "In which direction is the [REF_B] from the [REF_A]?",
    "What is the bearing from the [REF_A] to the [REF_B]?",
    "From the [REF_A], where is the [REF_B] located?",
    "What is the absolute heading from the [REF_A] to the [REF_B] in the ego coordinate system?",
]

def build_ref(target, total_targets):
    oid = target.get("object_id", "0")
    return f"Region [{oid}]"


def main():
    os.makedirs(OUTPUT_ROOT, exist_ok=True)

    dist_path = os.path.join(OUTPUT_ROOT, "inter_distance_vqa.json")
    angle_path = os.path.join(OUTPUT_ROOT, "inter_angle_diff_vqa.json")
    bearing_path = os.path.join(OUTPUT_ROOT, "inter_bearing_vqa.json")

    with open(dist_path, 'w') as dist_fp, \
         open(angle_path, 'w') as angle_fp, \
         open(bearing_path, 'w') as bearing_fp:

        dist_fp.write('[\n')
        angle_fp.write('[\n')
        bearing_fp.write('[\n')

        first_dist = True
        first_angle = True
        first_bearing = True

        total_processed = 0

        for source in DATA_SOURCES:
            root_dir = source["root"]
            scene_ids = source["scenes"]

            for scene_id in scene_ids:
                scene_dir = os.path.join(root_dir, scene_id)
                if not os.path.isdir(scene_dir):
                    continue

                video_names = [d for d in os.listdir(scene_dir) if os.path.isdir(os.path.join(scene_dir, d))]
                for video_name in sorted(video_names):

                    batch_files = sorted(glob.glob(os.path.join(scene_dir, video_name, "batch_*.json")))
                    for batch_file in batch_files:
                        try:
                            with open(batch_file, 'r') as f:
                                batch_data = json.load(f)
                        except:
                            continue

                        final_s = batch_data.get("final_s", 1.0)
                        if abs(final_s - 1.0) < 1e-3:
                            continue

                        if final_s > 100:
                            continue

                        batch_dist = []
                        batch_angle = []
                        batch_bearing = []

                        for frame in batch_data.get("frames", []):
                            image_name = frame.get("image_name")
                            targets = frame.get("targets", [])
                            inter_dists = frame.get("inter_target_distances", [])
                            if not inter_dists:
                                continue

                            abs_img = os.path.join(DATASET_ROOT, scene_id, video_name, image_name)

                            target_by_id = {t["object_id"]: t for t in targets}

                            for pair in inter_dists:
                                oid_a, oid_b = pair["object_id_pair"]
                                if oid_a not in target_by_id or oid_b not in target_by_id:
                                    continue

                                t_a, t_b = target_by_id[oid_a], target_by_id[oid_b]
                                ref_a = build_ref(t_a, len(targets))
                                ref_b = build_ref(t_b, len(targets))

                                dist_m = pair.get("distance_m", 0.0)

                                if dist_m > 80:
                                    continue
                                angle_diff = pair.get("global_relative_angle_deg", 0.0)
                                bearing = pair.get("bearing_from_first_to_second_deg", 0.0)

                                q = random.choice(DIST_TEMPLATES).replace("[REF_A]", ref_a).replace("[REF_B]", ref_b)
                                a = random.choice(DISTANCE_ANSWERS).replace("[DIST]", f"{dist_m:.2f}")
                                batch_dist.append({"messages": [{"role": "user", "content": f"<image> {q}"}, {"role": "assistant", "content": a}], "images": [abs_img]})

                                q = random.choice(ANGLE_TEMPLATES).replace("[REF_A]", ref_a).replace("[REF_B]", ref_b)
                                a = random.choice(ANGLE_DIFF_ANSWERS).replace("[ANGLE_DIFF]", f"{angle_diff:.2f}")
                                batch_angle.append({"messages": [{"role": "user", "content": f"<image> {q}"}, {"role": "assistant", "content": a}], "images": [abs_img]})

                                direction = "right" if bearing > 0 else "left" if bearing < 0 else "straight ahead"
                                q = random.choice(BEARING_TEMPLATES).replace("[REF_A]", ref_a).replace("[REF_B]", ref_b)
                                a = random.choice(BEARING_ANSWERS).replace("[BEARING]", f"{bearing:.2f}").replace("[DIRECTION]", direction)
                                batch_bearing.append({"messages": [{"role": "user", "content": f"<image> {q}"}, {"role": "assistant", "content": a}], "images": [abs_img]})

                        def write_items(fp, items, first_flag):
                            for item in items:
                                if not first_flag:
                                    fp.write(',\n')
                                fp.write(json.dumps(item, indent=2))
                                first_flag = False
                            return first_flag

                        first_dist = write_items(dist_fp, batch_dist, first_dist)
                        first_angle = write_items(angle_fp, batch_angle, first_angle)
                        first_bearing = write_items(bearing_fp, batch_bearing, first_bearing)
                        total_processed += len(batch_dist) + len(batch_angle) + len(batch_bearing)

        dist_fp.write('\n]')
        angle_fp.write('\n]')
        bearing_fp.write('\n]')

    print("Done:", total_processed)


if __name__ == "__main__":
    main()